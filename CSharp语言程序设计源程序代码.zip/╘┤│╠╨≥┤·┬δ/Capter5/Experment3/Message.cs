﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Experment3
{
    public  class Message:IMessage //定义实现接口的类
    {
        //1.定义存放添加学生的数组
        private Student[] s = new Student[3];
        //2.学生信息数组下标
        private static int count = 0;
        //3.重写接口中添加学生信息的方法
        public string  AddStudent(Student stu)
        {
            string mes = null;
            //4.判断学号是否重复
            foreach (Student st in s )
            {
                if (st != null && st.StuNo == stu.StuNo)
                {
                  mes=  string.Format("学生学号重复!");
                    
                }
            }
            if (count < s.Length)
            {
                s[count++] = stu;
                
               mes = string.Format("\n添加成功！");
            }
            else
            {
               mes=string.Format("\n学生信息已经录满！");
                  
            }
            return mes;
        }
        
    }
}
