﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Experment3
{
    
    interface IMessage //定义信息接口
    {
        /// <summary>
        /// 1.添加学生信息的方法
        /// </summary>
        /// <param name="stu"></param>
        /// <returns ></returns>
        string AddStudent(Student stu);
       
    }
}
