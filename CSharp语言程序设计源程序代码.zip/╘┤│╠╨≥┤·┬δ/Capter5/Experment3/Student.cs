﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Experment3
{
    public  class Student
    {
        //1.声明学生信息的私有字段
        private string stuNo;
        private string stuName;
        private string stuSex;
        private int stuAge;
        private string stuSpec;       
        //2.属性封装字段
        public string StuNo
        {
            get { return stuNo; }
            set { stuNo = value; }
        }
        public string StuName
        {
            get { return stuName; }
            set { stuName = value; }
        }
        public string StuSex
        {
            get { return stuSex; }
            set { stuSex = value; }
        }
        public int StuAge
        {
            get { return stuAge; }
            set { stuAge = value; }
        }
        public string StuSpec
        {
            get { return stuSpec; }
            set { stuSpec = value; }
        }
      
        //3.构造函数初始化字段
        public Student() { }
        public Student(string No, string Name, string Sex, int Age, string Spec)
        {
            this.stuNo = No;
            this.stuName = Name;
            this.stuSex = Sex;
            this.stuAge = Age;
            this.stuSpec = Spec;
        }
        //4.显示学生信息的方法
        public string Display()
        {
            return string.Format("学生信息：\n学号：{0}\n姓名：{1}\n性别：{2}\n年龄：{3}\n专业：{4}",StuNo ,StuName ,StuSex ,StuAge ,StuSpec );
        }
    }
}
