﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    public  class Person
    {
        //1.定义姓名、性别、年龄私有字段
        private string name;
        private string sex;
        private int age;
        //2.属性封装字段
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Sex
        {
            get { return sex; }
            set { sex = value; }
        }
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        //3.构造函数初始化字段
        public Person(string myNme, string mySex, int myAge)
        {
            this.name = myNme;
            this.sex = mySex;
            this.age = myAge;
        }
    }
}
