﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    public class Student:Person 
    {
        //1.扩展学生类的学号、专业私有字段
        private string stuNo;
        private string stuSpecialty;
        //2.属性封装私有字段
        public string StuNo
        {
            get { return stuNo; }
            set { stuNo = value; }
        }
        public string StuSpecialty
        {
            get { return stuSpecialty; }
            set { stuSpecialty = value; }
        }
        //3.构造函数初始化字段
        public Student (string myNo,string myName,string mySex,int myAge,string mySpecialty):base( myName, mySex, myAge)
        {
            this.stuNo = myNo;
            this.stuSpecialty = mySpecialty;
        }
        //4.定义一个显示学生信息的方法
        public string GetMessage()
        {
            return string.Format("学生信息如下：\n学号：{0}\n姓名：{1}\n性别：{2}\n年龄：{3}\n专业：{4}",StuNo ,Name ,Sex ,Age ,StuSpecialty );
        }
    }
}
