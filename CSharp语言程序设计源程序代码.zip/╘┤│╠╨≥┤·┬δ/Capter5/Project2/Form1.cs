﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 多态性：是指同一操作作用于不同的对象，会产生不同的结果。
        /// </summary>
        Person[] ps; //在两个事件外部定义一个人类数组，用以存放各种不同类的人对象便于访问
        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            Cperson cps = new Cperson(txtCname.Text);
            Aperson aps = new Aperson(txtAname.Text);
            Eperson eps = new Eperson(txtEname.Text);
            lblShow.Text = "添加一个中国人，姓名是：" + cps.Name.ToString();
            lblShow.Text += "\n添加一个美国人，姓名是：" + aps.Name.ToString();
            lblShow.Text += "\n添加一个英国人，姓名是：" + eps.Name.ToString();
            ps= new Person[] { cps, aps, eps };
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < ps.Length; i++)
            {
                lblShow.Text += string.Format("\n{0}", ps[i].GetMessage());
            }
        }
    }
}
