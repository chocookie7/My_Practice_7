﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    public  class Aperson:Person 
    {
        public Aperson(string Aname)
            : base(Aname)
        {

        }
        //重写基类的方法
        public override  string GetMessage()
        {
            return string.Format("我是美国人，姓名：{0},从事软件项目管理", Name);
        }
    }
}
