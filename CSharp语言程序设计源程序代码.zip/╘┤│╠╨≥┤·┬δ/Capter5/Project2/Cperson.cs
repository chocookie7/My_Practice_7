﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
   public  class Cperson:Person 
    {
       public Cperson(string myname)
           : base(myname)
       {

       }
       //重写Person类的方法
       public override  string GetMessage()
       {
           return string.Format("我是中国人，姓名：{0},从事软件代码编写", Name);
       }
    }
}
