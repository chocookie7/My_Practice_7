﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
   public  class Eperson:Person 
    {
       public Eperson(string Ename)
           : base(Ename)
       {

       }
       public override  string GetMessage()
       {
           return string.Format("我是英国人，姓名：{0},从事软件架构设计", Name);
       }
    }
}
