﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            //实例化DirectoryInfo类对象，其参数为D:\\Capter10
            DirectoryInfo dir = new DirectoryInfo("D:\\Capter10");
            //调用创建文件夹方法Create()
            dir.Create();
            //调用在指定文件夹下创建子文件夹的方法CreateSubdirectory()
            dir.CreateSubdirectory("Project1");
            dir.CreateSubdirectory("Project2");
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //实例化DirectoryInfo类对象，其参数为D:\\Capter10
            DirectoryInfo directory= new DirectoryInfo("D:\\Capter10");
            //调用返回当前目录 directory信息的可枚举集合IEnumerable<DirectoryInfo > dir
            IEnumerable<DirectoryInfo > dir = directory.EnumerateDirectories();
            //遍历枚举集合将其集合元素输出到窗体Form1的标签处
            foreach (var d in dir)
            {
                lblShow.Text +="\n"+ string.Format(d.Name);
            }
        }
    }
}
