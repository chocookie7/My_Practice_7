﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;  //文件流所需的命名空间
using System.Runtime.Serialization.Formatters.Binary;//添加序列化类所需命名空间

namespace Project8
{
    [Serializable]   //指示学生类是可序列化的类
    public  class Student
    {
        //定义字段变量
       public  string stuNo;
       public  string stuName;
       public string stuSex;
       public string stuSpec;
        //通过构造函数对字段变量初始化
        public Student(string No, string Name, string Sex, string Spec)
        {
            this.stuNo = No;
            this.stuName = Name;
            this.stuSex = Sex;
            this.stuSpec = Spec;
        }
    }
     [Serializable]   //指示学生列表类是可序列化的类
    public class StudentList
    {
         //定义学生类数组
         Student[] list = new Student[100];
         //定义索引器
         public Student this[int index]
         {
             get
             {
                 if (index < 0 || index >= 100) //检查索引范围
                 {
                     return list[0];
                 }
                 else
                 {
                     return list[index];
                 }
             }
             set
             {
                 //也可判断在 index >= 0 && index < 100范围内
                 if (!(index < 0 || index >= 100)) 
                 {
                     list[index] = value;
                 }
             }
         }
    }
}
