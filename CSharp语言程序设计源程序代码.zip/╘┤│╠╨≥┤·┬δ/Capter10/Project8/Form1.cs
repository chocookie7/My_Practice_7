﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Project8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public StudentList stuList = new StudentList();
        public  int n = 0;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //定义字段获取前台文本框中输入的数据
            string stuNo = txtStuNo.Text;
            string stuName = txtStuName.Text;
            string stuSpec = txtSpec.Text;
            string stuSex = string.Empty;
            if (rdoMale.Checked) { stuSex = "男"; }
            else { stuSex = "女"; }
            //把学生添加到列表中
            Student students = new Student(stuNo, stuName, stuSex, stuSpec);
            stuList[n] = students;
            n++;
            MessageBox.Show("添加一个学生信息到学生列表中！");
        }
        //[保存]按钮单击事件显示保存文件对话框
        private void btnSave_Click(object sender, EventArgs e)
        {
            sfDialog.ShowDialog(); //显示另存为对话框
        }
        //文件保存对话框的[保存]按钮单击时触发FileOk()事件
        private void sfDialog_FileOk(object sender, CancelEventArgs e)
        {
            Stream fileSave = sfDialog.OpenFile();//打开指定文件
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fileSave, stuList);
            fileSave.Close();
            MessageBox.Show("数据成功保存！\n" + "文件名为：" + sfDialog.FileName);
        }
        //[打开]按钮单击事件显示打开文件对话框
        private void btnOoen_Click(object sender, EventArgs e)
        {
            if (ofDialog.ShowDialog() == DialogResult.OK)
            {
                txtFile.Text = ofDialog.FileName;
            }
        }
        //打开对话框的[打开]按钮单击时触发FileOk()事件
        private void ofDialog_FileOk(object sender, CancelEventArgs e)
        {
            lstShow.Items.Clear();
            lstShow.Items.Add("学号\t        姓名\t性别\t专业");
            Stream fileOpen = ofDialog.OpenFile();    //打开选中的文件
            BinaryFormatter bf = new BinaryFormatter();//创建序列化对象
            StudentList stus = (StudentList)bf.Deserialize(fileOpen);//把流反序列化
            int k = 0;
            while (stus[k] != null)
            {
                string stuNo = stus[k].stuNo;
                string stuName = stus[k].stuName;
                string stuSex = stus[k].stuSex;
                string stuSpec = stus[k].stuSpec;
                string result = string.Format("{0}\t{1}\t{2}\t{3}", stuNo, stuName, stuSex, stuSpec);
                lstShow.Items.Add(result);
                k++;       
            }
            fileOpen.Close();
        }
    }
}
