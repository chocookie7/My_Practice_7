﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWriteFile_Click(object sender, EventArgs e)
        {
            //定义文件路径
            string path = @"D:\Capter10\Project1\student.txt";
            //创建FileStream实例对象
            FileStream writeName = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
            //定义学号、姓名、专业字符串
            string stuNo = txtStuNo.Text;
            string stuName = txtStuName.Text;
            string stuSpec = txtSpecialty.Text;

            //将字符串转变为字节数组
            byte[] bytes0 = Encoding.UTF8.GetBytes(stuNo);
            byte[] bytes1 = Encoding.UTF8.GetBytes(stuName);
            byte[] bytes2 = Encoding.UTF8.GetBytes(stuSpec);
            // 向文件中写入字节数组
            writeName.Write(bytes0, 0, bytes0.Length);
            writeName.Write(bytes1, 0, bytes1.Length);
            writeName.Write(bytes2, 0, bytes2.Length);
            //刷新缓冲区
            writeName.Flush();
            //关闭流
            writeName.Close();
            lblShow.Text = "文本框输入数据写入到文件中！\n";
        }

        private void btnReader_Click(object sender, EventArgs e)
        {
            //定义文件路径
            string path = @"D:\Capter10\Project1\student.txt";
            //判断指定的文件是否存在
            if (File.Exists(path))
            {
                FileStream readName = new FileStream(path,FileMode.Open ,FileAccess.Read );
                //定义存放文件信息的字节数组
                byte[] bytes=new byte[readName.Length];
                //读取文件信息
                readName.Read(bytes, 0, bytes.Length);
                //将得到的字节型数组重写编码为字符型数组
                char[] ch = Encoding.UTF8.GetChars(bytes);
                //输出读取文件信息
                lblShow.Text += "\n" +"读取文件信息是：\n";
                foreach (var by in ch)
                {
                    lblShow.Text +=  by;
                }
                //关闭流
                readName.Close();
            }
            else
            {
                lblShow.Text += "\n" + "你读取的文件不存在！";
            }
        }
    }
}
