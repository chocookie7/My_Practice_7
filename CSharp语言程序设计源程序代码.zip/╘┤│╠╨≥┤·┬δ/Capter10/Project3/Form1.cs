﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            //实例化DirectoryInfo类对象，其参数为D:\\Capter10
            DirectoryInfo dir = new DirectoryInfo("D:\\Capter10");
            //调用创建文件夹方法Create()
            dir.Create();
            //调用在指定文件夹下创建子文件夹的方法CreateSubdirectory()
            dir.CreateSubdirectory("Project1");
            dir.CreateSubdirectory("Project2");
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //实例化DirectoryInfo类对象，其参数为D:\\Capter10
            DirectoryInfo directory = new DirectoryInfo("D:\\Capter10");
            //调用返回当前目录 directory信息的可枚举集合IEnumerable<DirectoryInfo > dir
            IEnumerable<DirectoryInfo> dir = directory.EnumerateDirectories();
            //遍历枚举集合将其集合元素输出到窗体Form1的标签处
            foreach (var d in dir)
            {
                lblShow.Text += "\n" + string.Format(d.Name);
            }
        }

        //创建FileInfo文件类对象
        FileInfo fileInfo = new FileInfo("D:\\Capter10\\Project1\\Text1.txt");
        private void btnCreateFile_Click(object sender, EventArgs e)
        {
            ////创建FileInfo文件类对象
            //FileInfo fileInfo = new FileInfo("D:\\Capter10\\Project1\\Text1.txt");
            //判断文件类对象中文件名是否存在
            if (!fileInfo.Exists)
            {
                //创建文件
                fileInfo.Create();
            }
            //设置文件的相关属性
            fileInfo.Attributes = FileAttributes.Normal;
            lblShow.Text = string.Format("文件路径：{0}\n文件名称：{1}\n文件是否只读：{2}\n文件大小：{3}",fileInfo .Directory ,fileInfo .Name ,fileInfo .IsReadOnly ,fileInfo.Length );
        }

        private void btnMoveFile_Click(object sender, EventArgs e)
        {
            FileInfo newfileInfo = new FileInfo("D:\\Capter10\\Project2\\Text1.txt");
            if (!newfileInfo.Exists)
            {
                //移动文件到指定路径
                fileInfo.MoveTo("D:\\Capter10\\Project2\\Text1.txt");
            }
            lblShow.Text += "\n" + "文件名为Test1.txt的文件从Project1移到Project2文件夹"; 
        }         
    }
}
