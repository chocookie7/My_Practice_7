﻿namespace Project3
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblShow = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnCreateFile = new System.Windows.Forms.Button();
            this.btnMoveFile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblShow
            // 
            this.lblShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShow.Location = new System.Drawing.Point(15, 16);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(314, 152);
            this.lblShow.TabIndex = 0;
            // 
            // btnCreate
            // 
            this.btnCreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreate.Location = new System.Drawing.Point(335, 16);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(111, 31);
            this.btnCreate.TabIndex = 5;
            this.btnCreate.Text = "创建文件夹";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDisplay.Location = new System.Drawing.Point(335, 55);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(111, 31);
            this.btnDisplay.TabIndex = 4;
            this.btnDisplay.Text = "显示文件夹";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btnCreateFile
            // 
            this.btnCreateFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreateFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateFile.Location = new System.Drawing.Point(335, 93);
            this.btnCreateFile.Name = "btnCreateFile";
            this.btnCreateFile.Size = new System.Drawing.Size(111, 31);
            this.btnCreateFile.TabIndex = 6;
            this.btnCreateFile.Text = "创建文件";
            this.btnCreateFile.UseVisualStyleBackColor = true;
            this.btnCreateFile.Click += new System.EventHandler(this.btnCreateFile_Click);
            // 
            // btnMoveFile
            // 
            this.btnMoveFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoveFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMoveFile.Location = new System.Drawing.Point(335, 134);
            this.btnMoveFile.Name = "btnMoveFile";
            this.btnMoveFile.Size = new System.Drawing.Size(111, 31);
            this.btnMoveFile.TabIndex = 7;
            this.btnMoveFile.Text = "移动文件";
            this.btnMoveFile.UseVisualStyleBackColor = true;
            this.btnMoveFile.Click += new System.EventHandler(this.btnMoveFile_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 178);
            this.Controls.Add(this.btnMoveFile);
            this.Controls.Add(this.btnCreateFile);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.lblShow);
            this.Name = "Form1";
            this.Text = "新建和移动文件";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblShow;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnCreateFile;
        private System.Windows.Forms.Button btnMoveFile;
    }
}

