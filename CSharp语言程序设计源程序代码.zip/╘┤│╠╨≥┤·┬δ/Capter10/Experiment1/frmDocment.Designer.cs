﻿namespace Experiment1
{
    partial class frmDocment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtScore = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // rchtxtScore
            // 
            this.rchtxtScore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchtxtScore.Location = new System.Drawing.Point(0, 0);
            this.rchtxtScore.Name = "rchtxtScore";
            this.rchtxtScore.Size = new System.Drawing.Size(477, 301);
            this.rchtxtScore.TabIndex = 0;
            this.rchtxtScore.Text = "";
            // 
            // frmDocment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 301);
            this.Controls.Add(this.rchtxtScore);
            this.Name = "frmDocment";
            this.Text = "文档编辑";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtScore;
    }
}