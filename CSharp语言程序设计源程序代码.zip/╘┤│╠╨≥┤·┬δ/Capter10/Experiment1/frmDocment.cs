﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment1
{
    public partial class frmDocment : Form
    {
        public frmDocment()
        {
            InitializeComponent();
        }
        public RichTextBox Source
        {
            get { return rchtxtScore; }
            set { rchtxtScore = value; }
        }
    }
    
}
