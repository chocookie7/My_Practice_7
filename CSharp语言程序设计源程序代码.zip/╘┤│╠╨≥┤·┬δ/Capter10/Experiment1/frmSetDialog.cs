﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment1
{
    public partial class frmSetDialog : Form
    {
        public frmSetDialog()
        {
            InitializeComponent();
        }
        public string docPosition
        {
            get
            {
                return txtPosition.Text;
            }
        }
        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtPosition.Text = "";
            this.Hide();
        }

        //浏览的单击事件实现显示“浏览文件夹”对话框及返回选中的文件夹路径
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtPosition.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        
    }
}
