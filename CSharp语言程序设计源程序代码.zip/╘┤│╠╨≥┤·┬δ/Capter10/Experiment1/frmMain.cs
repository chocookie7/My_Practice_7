﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment1
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        //定义3个变量，分别是窗体记录器实现已创建的“文档”窗体进行记数、打开或保存文档的默认位置、文档窗体对象
        private int Count = 0;
        private string initialPos = string.Empty;
        private frmDocment doc;
        //文件菜单中新建菜单功能
        private void newFile_Click(object sender, EventArgs e)
        {
            Count++;
            doc = new frmDocment();
            doc.MdiParent = this;
            doc.Text = "文档" + Count;
            doc.Show();
        }
        /// <summary>
        /// 工具菜单中选项设置功能：创建“选项”设置对话框，显示“选项设置”对话框，获取已设置的默认文档位置，关闭“选项设置”对话框，设置“打开”和“另存为”对话框的默认文件夹
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OptionMenuItem_Click(object sender, EventArgs e)
        {       
            frmSetDialog fsd = new frmSetDialog();
            fsd.ShowDialog();
            initialPos = fsd.docPosition;
            fsd.Close();
            openFileDialog1.InitialDirectory = initialPos;
            saveFileDialog1.InitialDirectory = initialPos;
        }
        //文件菜单中打开菜单功能
        private void OpenFile_Click(object sender, EventArgs e)
        {
            RichTextBoxStreamType fileType = RichTextBoxStreamType.RichText;//赋一个初值
            //显示打开对话框
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //判断文档类型
                
                switch (openFileDialog1.FilterIndex)
                {
                    case 1: fileType = RichTextBoxStreamType.PlainText; break;
                    case 2: fileType = RichTextBoxStreamType.RichText; break;
                    default: fileType = RichTextBoxStreamType.UnicodePlainText; break;
                }
            }
            Count++;
            doc = new frmDocment();
            doc.MdiParent = this;
            doc.Text = openFileDialog1.FileName;//设置文档窗体的标题
            //加载文档，输出到ricchTextBox控件上
            doc.Source.LoadFile(openFileDialog1.FileName, fileType);
            doc.Show();
        }
        //文件菜单中保存菜单功能
        private void SaveFile_Click(object sender, EventArgs e)
        {
            RichTextBoxStreamType fileType = RichTextBoxStreamType.UnicodePlainText;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                switch (openFileDialog1.FilterIndex)
                {
                    case 1: fileType = RichTextBoxStreamType.PlainText; break;
                    case 2: fileType = RichTextBoxStreamType.RichText; break;
                    default: fileType = RichTextBoxStreamType.UnicodePlainText; break;
                }
            }
            doc.Source.SaveFile(saveFileDialog1.FileName, fileType);
        }
        ////文件菜单中关闭菜单功能
        private void CloseFile_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //格式菜单的字体菜单功能
        private void fontMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK && doc != null)
            {
                doc.Source.SelectionFont = fontDialog1.Font;
            }
        }
        //格式菜单的字体菜单功能
        
        private void ColorMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK && doc != null)
            {
                doc.Source.SelectionColor = colorDialog1.Color;
            }
        }  
    }
}
