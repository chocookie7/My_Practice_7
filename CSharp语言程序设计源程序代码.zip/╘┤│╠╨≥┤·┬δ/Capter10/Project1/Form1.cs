﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //创建磁盘驱动器对象，通过对象.属性实现信息显示
            DriveInfo drive = new DriveInfo("D");
            lblShow.Text = string.Format("驱动器名称：{0}\n\n驱动器类型：{1}\n\n驱动器文件格式：{2}\n\n驱动器可用空间大小：{3}\n\n驱动器总大小：{4}", drive.Name, drive.DriveType, drive.DriveFormat, drive.TotalFreeSpace, drive.TotalSize);
        }
    }
}
