﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;    //以下是用户手动导入的命名空间
using System.Runtime.Serialization.Formatters.Binary;

namespace Project7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //实例化学生列表对象，定义一个计器变量n
        public StudentList stuList = new StudentList();
        public int n = 0;
        private void btnAdd_Click(object sender, EventArgs e)//添加按钮单击事件
        {
            //定义字段获取前台文本框中输入的数据
            string stuNo = txtStuNo.Text;
            string stuName = txtStuName.Text;
            string stuSpec = txtSpec.Text;
            string stuSex = string.Empty;
            if (rdoMale.Checked) { stuSex = "男"; }
            else { stuSex = "女"; }
            //把学生添加到列表中
            Student students = new Student(stuNo, stuName, stuSex, stuSpec);
            stuList[n] = students;
            n++;
            MessageBox.Show("添加一个学生信息到学生列表中！");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string file = @"d:\Capter10\stuednt1.dat";
            Stream streamFile = new FileStream(file, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter formatFile = new BinaryFormatter();
            formatFile.Serialize(streamFile, stuList);
            streamFile.Close();
            MessageBox.Show("将学生列表信息保存到文件中!");
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            lstShow.Items.Clear();
            lstShow.Items.Add("学号\t        姓名\t性别\t专业");
            string file = @"d:\Capter10\stuednt1.dat";
            Stream streamFile = new FileStream(file, FileMode.Open, FileAccess.Read);
            BinaryFormatter formatFile = new BinaryFormatter();
            StudentList students = (StudentList)formatFile.Deserialize(streamFile);
            int m = 0;
            while (students[m] != null)
            {
                string sNo = students[m].stuNo;
                string sName = students[m].stuName;
                string sSex = students[m].stuSex;
                string sSpec = students[m].stuSpec;
                string result = string.Format("{0}\t{1}\t{2}\t{3}", sNo, sName, sSex, sSpec);
                lstShow.Items.Add(result);
                m++;
            }
            streamFile.Close();
        }
    }
}
