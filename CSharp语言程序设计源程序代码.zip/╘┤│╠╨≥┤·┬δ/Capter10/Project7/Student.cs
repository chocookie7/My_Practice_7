﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;  //用户手动导入的命名空间
using System.Runtime.Serialization.Formatters.Binary;

namespace Project7
{
    [Serializable] //指示学生类是可序列化类
    public class Student //定义学生类
    {
        //定义4个字段变量
        public string stuNo;
        public string stuName;
        public string stuSex;
        public string stuSpec;
        //采用构造函数初始化字段
        public Student(string No, string Name, string Sex, string Spec)
        {
            this.stuNo = No;
            this.stuName = Name;
            this.stuSex = Sex;
            this.stuSpec = Spec;
        }
    }
    [Serializable]  //指示学生列表类是可序列化类
    public class StudentList
    {
        //定义学生类数组list保存添加学生信息
        private Student[] list = new Student[100];
        //定义索引器来检查索引的范围
        public Student this[int index]
        {
            get
            {
                if (index < 0 || index >= 100)
                {
                    return list[0];
                }
                else
                {
                    return list[index];
                }
            }
            set
            {
                if (!(index < 0 || index >= 100))
                {
                    list[index] = value;
                }

            }
        }
     }

}
