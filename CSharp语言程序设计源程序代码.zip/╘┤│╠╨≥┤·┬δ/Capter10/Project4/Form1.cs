﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            string path = @"D:\Capter10\Project2\Test1.txt";
            //创建StreamWriter类的实例对象
            StreamWriter writeFile = new StreamWriter(path);
            //向文件中写入学生的学号
            writeFile.WriteLine("2330190101");
            //向文件中写入学生姓名
            writeFile.WriteLine("陈伟");
            //向文件中写入学生专业
            writeFile.WriteLine("计算机科学与技术");
            //刷新缓存
            writeFile.Flush();
            //关闭流
            writeFile.Close();
            lblShow.Text += "信息写入到指定的文件中！\n";
        }

        private void btnReader_Click(object sender, EventArgs e)
        {
            string path = @"D:\Capter10\Project2\Test1.txt";
            //创建StreamReader类实例对象
            StreamReader readerFile = new StreamReader(path);
            //判断文件中是否有字符
            if (readerFile.Peek() != -1)
            {
                //读取文件Test1.txt中的一行字符串
                lblShow.Text += "\n" +  readerFile.ReadToEnd();
            }
            readerFile.Close();
        }
    }
}
