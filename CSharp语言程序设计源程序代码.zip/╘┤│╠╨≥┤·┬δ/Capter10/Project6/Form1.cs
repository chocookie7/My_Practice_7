﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //创建FileStream类实例对象,参数：指定创建文件路径，文件访问方式为写入，文件模式为打开文件追加内容
            FileStream fs = new FileStream(@"D:\Capter10\Project2\student.dat",FileMode.Append ,FileAccess .Write );
            //通过文件流写文件
            BinaryWriter writeFile = new BinaryWriter(fs);
            //分别写入学号、姓名、专业的字符串
            writeFile.Write(txtStuNo.Text);
            writeFile.Write(txtStuName.Text);
            writeFile.Write(txtSpec.Text);
            //性别判断后写入字符串
            string sex = string.Empty;
            if (rdoMale.Checked) { sex = "男"; }
            else { sex = "女"; }
            writeFile.Write(sex);
            //关闭流
            fs.Close();
            writeFile.Close();
            MessageBox.Show("文件保存成功！");
        }

        private void btnOoen_Click(object sender, EventArgs e)
        {

            lstShow.Items.Clear(); //清除列表控件的元素
            //在列表控件中添加输入数据的表头
            lstShow .Items .Add ("学号\t        姓名\t性别\t专业");
            //创建FileStream类实例对象,参数：指定打开文件路径，文件访问方式为读取，文件模式为打开文件
            FileStream fs=new FileStream (@"D:\Capter10\Project2\student.dat",FileMode.Open ,FileAccess .Read );
            //通过文件流读文件
            BinaryReader readFile=new BinaryReader (fs);
            //获取当前流位置
            fs.Position =0;
            //循环读取文件中的字符串，字符串默认空格隔开
            while(fs.Position !=fs.Length )
            {
                //读出文件student.dat中的字符串到相应的变量中
                string stuNo=readFile .ReadString ();
                String stuName=readFile .ReadString ();
                string spec=readFile .ReadString ();
                string sex=readFile .ReadString ();
                string result=string.Format ("{0}\t{1}\t{2}\t{3}",stuNo ,stuName ,sex,spec );
                lstShow.Items .Add (result );
            }
            readFile .Close ();
            fs.Close ();
        }
    }
}
