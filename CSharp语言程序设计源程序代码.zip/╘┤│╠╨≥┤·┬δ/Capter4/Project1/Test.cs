﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    public  class Test
    {
        private int id;              //定义私有的整型字段id
        public readonly string name; //定义公有的只读字符串型字段name
        internal static int age;     //定义内部的静态的整型字段age
        private const string job = "软件工程师";//定义私有字符串型常量job
    }
}
