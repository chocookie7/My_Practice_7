﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
   public  class Person
    {
       //属性成员
        private string name;
        private string sex;
        private int age;
        private double height;
        private double weight;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Sex
        {
            get { return sex; }
            set { sex = value; }
        }
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public double Height
        {
            get { return height; }
            set { height = value; }
        }
        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        }
       //行为成员
       public string GetMessage()
       {
           return string.Format("我的名字叫：{0},性别是：{1},今年{2}岁，身高：{3}，体重：{4}来自湖北武汉");
       }
    }
}
