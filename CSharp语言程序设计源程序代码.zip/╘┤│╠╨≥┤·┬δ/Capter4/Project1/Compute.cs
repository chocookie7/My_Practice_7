﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    class Compute
    {
        #region 1.分别定义4个方法实现
        ////加法
        //private double Add(double num1, double num2)
        //{
        //    return num1 + num2;
        //}
        ////减法
        //private double Sub(double num1, double num2)
        //{
        //    return num1 - num2;
        //}
        ////乘法
        //private double Mul(double num1, double num2)
        //{
        //    return num1 * num2;
        //}
        ////除法
        //private string Div(double num1, double num2)
        //{
        //    if (num2 != 0) { return Convert .ToString ( num1 / num2); }
        //    else { return string.Format("除法分母不得为0！"); }
        //}
        #endregion

        #region 2.定义1个方法实现加减乘除功能
        public double ComputeResult(double num1, string symbol, double num2)
        {
            double result=0;
            switch (symbol)
            {
                case "+": result = num1 + num2;
                    break;
                case "-": result = num1 - num2;
                    break;
                case "*": result = num1 * num2;
                    break;
                case "/": if (num2 != 0) { result = num1 / num2; }
                    else { result = 0; }
                    break;
            }
            return result;
        }
        #endregion
    }
}
