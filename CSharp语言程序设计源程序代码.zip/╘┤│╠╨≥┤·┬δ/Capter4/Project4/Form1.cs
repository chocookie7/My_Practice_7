﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Person ps = new Person();
            ps.Name = txtName.Text;
            ps.Sex = txtSex.Text;
            ps.Age = Convert.ToInt32(txtAge.Text);
            ps.Height =Convert .ToDouble ( txtHeight.Text);
            ps.Weight =Convert .ToDouble ( txtWeight.Text);
            lblShow.Text = ps.GetMessage();
        }
    }
}
