﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //窗体加载事件中将生成的随机数视为验证码加载到窗体的指定标签处
            Random rd = new Random();
            int num = rd.Next(1000, 9999);//产生一个4位数的验证码
            lblShow.Text = num.ToString();
        }

        private void lblShow_Click(object sender, EventArgs e)
        {
            //单击标签将重新生成新的随机数
            Random rd = new Random();
            int num = rd.Next(1000, 9999);//产生一个4位数的验证码
            lblShow.Text = num.ToString();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //单击登录按钮实现消息框的弹出
            if (txtCode.Text != lblShow.Text)
            {
                MessageBox.Show("验证码错误！");
            }
            else if (txtName.Text == "Admin" && txtPwd.Text == "123456")
            {
                MessageBox.Show("用户登录成功！");
            }
            else
            {
                MessageBox.Show("用户登录失败！");
            }
        }
    }
}
