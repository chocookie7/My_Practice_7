﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3
{
    class Person
    {
        private string name;
        private string sex;
        private int age;
        private double height;
        private double weight;
        public string Name  //设置姓名为只读属性
        {
            get { return name; }            
        }
        public string Sex //设置性别为自动属性
        {
            get;
            set;
        }
        public int Age //约束年龄字段为非负整数属性
        {
            get { return age; }
            set
            {
                if (value < 0) { value = 0; }
                else { age = value; }
            }
        }
        public double Height //设置身高为读、写属性
        {
            get { return height; }
            set { height = value; }
        }
        public double Weight  //设置体重为读、写属性
        {
            get { return weight; }
            set { weight = value; }
        }
    }
}
