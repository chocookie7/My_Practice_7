﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Experiment1
{
   public  class Student
    {
       //1.定义5个私有字段
       private string stuNo;
       private string stuName;
       private string stuSex;
       private int stuAge;
       private string stuSpecialty;
       //2.构造函数初始化字段
       public Student(string myNo, string myName, string mySex, int myAge, string mySpecialty)
       {
           this.stuNo = myNo;
           this.stuName = myName;
           this.stuSex = mySex;
           this.stuAge = myAge;
           this.stuSpecialty = mySpecialty;
       }
       //3.只读属性读取学号、姓名、性别
       public string StuNo
       {
           get { return stuNo; }
       }
       public string StuName
       {
           get { return stuName; }
       }
       public string StuSex
       {
           get { return stuSex; }
       }
       //4.读写属性读写年龄、专业
       public int StuAge
       {
           get
           {
               if (stuAge <= 0) { return 0; }
               else { return stuAge; }
           }
           set { stuAge = value; }
       }
       public string StuSpecialty
       {
           get
           {
               if (stuSpecialty ==null) { return "未输入"; }
               else { return stuSpecialty; }
           }
           set { stuSpecialty = value; }
       }
       //5.通过访问属性返回学生信息的方法GetMessage()
       public string GetMessage()
       {
           return string.Format("添加学生信息为：\n学号：{0}\n姓名：{1}\n性别：{2}\n年龄：{3}\n专业：{4}\n",StuNo ,StuName ,StuSex ,StuAge ,StuSpecialty );
       }
    }
}
