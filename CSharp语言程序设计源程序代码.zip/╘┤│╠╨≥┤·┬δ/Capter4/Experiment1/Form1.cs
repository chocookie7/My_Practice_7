﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Student stu = new Student(txtNo.Text, txtName.Text, txtSex.Text, Convert.ToInt32(txtAge.Text), txtSpecialty.Text);
            lblShow.Text = stu.GetMessage();
        }
    }
}
