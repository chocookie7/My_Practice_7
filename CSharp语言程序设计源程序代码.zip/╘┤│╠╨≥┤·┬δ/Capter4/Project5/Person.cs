﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project5
{
    public  class Person
    {
        public string Name { get; set; }
        public string Sex { get; set; }
        public int Age { get; set; }
        public double Height { get; set; }
        public double Weight { get; set; }
        //定义一个对属性赋值的方法
        public void SetPerson(string myname, string mysex, int myage, double myheight, double myweight)
        {
            Name = myname;
            Sex = mysex;
            Age = myage;
            Height = myheight;
            Weight = myweight;
        }
        //定义一个输出属性值的方法
        public string GetMessage()
        {
            return string.Format("基本信息：\n姓名：{0}\n性别：{1}\n年龄：{2}\n身高：{3}\n体重：{4}\n", Name, Sex, Age, Height, Weight);
        }
    }
}
