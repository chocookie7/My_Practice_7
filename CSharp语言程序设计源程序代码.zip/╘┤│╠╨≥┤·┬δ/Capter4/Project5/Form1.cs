﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Person ps = new Person();
            ps.SetPerson(txtName.Text, txtSex.Text, Convert.ToInt32(txtAge.Text), Convert.ToDouble(txtHeight.Text), Convert.ToDouble(txtWeight.Text));
            lblShow .Text +="\n"+ ps.GetMessage();
        }
    }
}
