﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime dt = new DateTime();
            dt = DateTime.Now;
            lblShow.Text = string.Format("当前日期是：{0}", dt);
            lblShow.Text += string.Format("\n当前是本月的：第{0}天", dt.Day);
            lblShow.Text += string.Format("\n当前是本周的：星期{0}", Convert .ToInt32  (dt.DayOfWeek));
            lblShow.Text += string.Format("\n当前是本年度的：第{0}天", dt.DayOfYear);
            lblShow.Text += string.Format("\n30天后的日期是：{0}", dt.AddDays(30));
        }
    }
}
