﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Course course = new Course();
            course.couId = txtCouId.Text;
            course.couName = txtCouName.Text;
            course.couCredit = txtCouCredit.Text;
            lblShow.Text = course.GetMessage();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
