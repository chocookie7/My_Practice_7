﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project11
{
   public partial  class Course
    {
       public string couId { get; set; }
       public string couName { get; set; }
       public string couCredit{ get; set; }
    }
   public partial class Course
   {
       public string GetMessage()
       {
           return string.Format("课程信息如下：\n课程编号：{0}\n课程名称：{1}\n课程学分：{2}\n",couId ,couName ,couCredit);
       }
   }
}
