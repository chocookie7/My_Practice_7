﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    class Book
    {
        //定义图书的5个字段，分别是编号、名称、价格、类型、出版社
        private int id;
        private string name;
        private double price;
        private string type;
        private string publishers;
        //设置图书编号、名称、价格、类型、出版社属性
        public int Id  //图书编号为读、写属性
        {
            get { return id; }
            set { id = value; }
        }
        public string Name //图书名称设置为只读属性
        {
            get { return name; }
        }
        public double Price //图书价格属性对字段的安全性保护
        {
            get { return price; }
            set 
            {
                if (value < 0) { value = 0; }
                else { price = value; }
            }
        }
        public string Type //图书类型的自动属性
        {
            get;
            set;
        }
        public string Publishers //图书出版社的读写属性
        {
            get { return publishers; }
            set { publishers = value; }
        }
    }
}
