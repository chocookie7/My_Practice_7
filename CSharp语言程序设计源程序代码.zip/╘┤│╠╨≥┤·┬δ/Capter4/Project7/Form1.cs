﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            int number1 = Convert.ToInt32(txtNum1.Text);
            int number2 = Convert.ToInt32(txtNum2.Text);
            FindNumber fmax = new FindNumber();
           lblShow .Text +="两个数中的最大数："+ fmax.GetMax(number1, number2);
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            int number1 = Convert.ToInt32(txtNum1.Text);
            int number2 = Convert.ToInt32(txtNum2.Text);
            int number3 = Convert.ToInt32(txtNum3.Text);
            FindNumber fmax = new FindNumber();
            lblShow.Text += "\n三个数中的最大数：" + fmax.GetMax(number1, number2, number3);
        }
    }
}
