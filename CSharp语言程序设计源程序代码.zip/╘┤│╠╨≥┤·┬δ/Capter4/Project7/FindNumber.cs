﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project7
{
    class FindNumber
    { 
        //1.定义求2个整型数据中的最大数方法
        public int GetMax(int num1, int num2)
        {
            return num1 > num2 ? num1 : num2;
        }
        //2.定义求3个整型数据中的最大数方法
        public int GetMax(int num1, int num2, int num3)
        {
            int max=num1;
            if (max < num2) { max = num2; }
            if (max < num3) { max = num3; }
            return max;
        }
    }
}
