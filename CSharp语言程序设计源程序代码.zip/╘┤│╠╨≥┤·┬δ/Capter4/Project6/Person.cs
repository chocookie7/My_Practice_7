﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project6
{
    public class Person
    {
        //定义数据字段
        private string name;
        private string sex;
        private int age;
        private double height;
        private double weight;
        //定义数据字段的属性
        public string Naem
        {
            get { return name; }
            set { name = value; }
        }
        public string Sex
        {
            get { return sex; }
            set { sex = value; }
        }
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public double Height
        {
            get { return height; }
            set { height = value; }
        }
        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        }
        //定义带参数构造方法对属性初始化
        public Person(string myName, string mySex, int myAge, double myHeight, double myWeight)
        {
            this.Naem = myName;
            this.Sex = mySex;
            this.Age = myAge;
            this.Height = myHeight;
            this.Weight = myWeight;
        }
        //定义显示人的信息方法
        public string GetMessage()
        {
            return string.Format("基本信息:\n姓名：{0}\n性别：{1}\n年龄：{2}\n身高：{3}\n体重：{4}\n",this.Naem ,this.Sex ,this.Age ,this.Height ,this.Weight );
        }
    }
}
