﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSwap_Click(object sender, EventArgs e)
        {
            Swper sp = new Swper();//创建两数交换类对象sp
            int a = Convert.ToInt32(txtNum1.Text);
            int b = Convert.ToInt32(txtNum2.Text);
            //显示方法调用前的实参
            lblShow.Text += string.Format("\n主调方法：交换前：a={0}，b={1}", a, b);
            lblShow.Text += sp.Swap(ref a, ref b);
            //显示调用后的实参
            lblShow.Text += string.Format("\n主调方法：交换后：a={0}，b={1}", a, b);
            //把调用后的实参值重新加载到窗体的文本框中
            txtNum1.Text = a.ToString();
            txtNum2.Text = b.ToString();
        }
    }
}
