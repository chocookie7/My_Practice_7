﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project8
{
   public class Swper
    {
       //定义两数交换的方法Swap()
       public string Swap(ref int x,ref int y)
       {
           //1.方法执行前实参值
           string str=null;
               str+= string.Format("\n被调方法：交换前x={0}，y={1}", x, y);
           int temp = x;
           x = y;
           y = temp;
           //2.方法执行后实参值
           str += string.Format("\n被调方法：交换前x={0}，y={1}", x, y);
           return str;
       }
    }
}
