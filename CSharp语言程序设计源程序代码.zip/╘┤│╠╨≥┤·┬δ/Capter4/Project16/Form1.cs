﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            string str = txtString.Text.Trim(); ;
            string[] strs = str.Split(' ');
            lblShow .Text = string.Format("输入字符串{0}中共有单词数：{1}", str, strs.Length);
            for (int i = 0; i < strs.Length; i++)
            {
               lblShow .Text += string.Format("\n第{0}个单词是：{1}", i + 1, strs[i]);
            }
        }
    }
}
