﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //窗体加载时生成随机数验证码
            Random rd = new Random();
            int num = rd.Next(1000, 9999);
            lblShow.Text = num.ToString();
        }
        private void lblShow_Click(object sender, EventArgs e)
        {
            //单击生成验证码标签重新生成新的验证码
            Random rd = new Random();
            int num = rd.Next(1000, 9999);
            lblShow.Text = num.ToString();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
            {
                lblName.Text = string.Format ("用户名不得为空！");
            }
            else if (string.IsNullOrEmpty(txtPwd.Text))
            {
                lblPwd.Text = string.Format( "密码不得为空！");
            }
            else if (string.IsNullOrEmpty(txtCode.Text))
            {
                lblCode.Text = string.Format( "验证码不得为空！");
            }
            else if (txtCode.Text == lblShow.Text)
            {
                if (txtName.Text == "Admin" && txtPwd.Text == "123456")
                {
                    MessageBox.Show("用户登录成功！");
                }
                else
                {
                    MessageBox.Show("用户登录失败！");
                }
            }
            else
            {
                MessageBox.Show("验证码输入错误！");
            }
        }     
    }
}
