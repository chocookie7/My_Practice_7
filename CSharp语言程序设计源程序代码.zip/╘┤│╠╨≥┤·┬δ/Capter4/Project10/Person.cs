﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project10
{
    public class Person
    {
        public class Student
        {
            public string stuNo;
            public string stuName;
            public string stuSpecialty;
            public string GetMessage()
            {
                return string.Format("学生的基本信息：\n学号：{0}\n姓名：{1}\n专业：{2}\n",stuNo ,stuName ,stuSpecialty );
            }
        }
    }
}
