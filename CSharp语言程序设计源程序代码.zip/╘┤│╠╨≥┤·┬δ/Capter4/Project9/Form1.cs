﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAnalyzer_Click(object sender, EventArgs e)
        {
            Analyzer al = new Analyzer();//创建一个分析类对象
            string path = txtPath.Text;
            string dir;
            string file;
            al.SplitPath(path, out dir, out file);
            txtDir.Text = dir;
            lblShow.Text = "文件名是:" + file;
        }
    }
}
