﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project9
{
   public  class Analyzer
    {
       public void SplitPath(string path,out string dir,out string filename)
       {
           int i;
           i = path.LastIndexOf('\\'); //获取文件路径中最后一个反斜杠的位置
           dir = path.Substring(0, i); //最后一个反斜杠的字符串是文件目录
           filename = path.Substring(i + 1);//最后一个反斜杠后的字符串是文件名
       }
    }
}
