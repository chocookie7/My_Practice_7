﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Experiment2
{
    public  class Time
    {
        //1.定义时分秒3个私有字段
        private int hour;
        private int minute;
        private int second;
        //2.读写时分秒属性
        public int Hour
        {
            get { return hour; }
            set { hour = value; }
        }
        public int Minute
        {
            get { return minute; }
            set { minute = value; }
        }
        public int Second
        {
            get { return second; }
            set { second = value; }
        }
        //3.默认构造函数获得系统时间
        public Time()
        {
            hour = DateTime.Now.Hour;
            minute = DateTime.Now.Minute;
            second = DateTime.Now.Second;
        }
        //4.定义带参数的构造函数对时间初始化
        public Time(int myHour, int myMinute, int mySecond)
        {
            this.hour = myHour;
            this.minute = myMinute;
            this.second = mySecond;
        }
        //5.定义秒加1的方法AddSecond()
        public void AddSecond()
        {
            second++;
            if (second >= 60) { second = second % 60; minute++; }
            if (minute >= 60) { minute = minute % 60; hour++; }
        }
    }
}
