﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Time tm=new Time ();
            txtHour.Text = Convert .ToString ( tm.Hour);
            txtMinute.Text = tm.Minute.ToString();
            txtSecond.Text = tm.Second.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Time tm = new Time(Convert.ToInt32(txtHour.Text), Convert.ToInt32(txtMinute.Text), Convert.ToInt32(txtSecond.Text));
            tm.AddSecond();
            txtSecond.Text = tm.Second.ToString();
            txtMinute.Text = tm.Minute.ToString();
            txtHour.Text = tm.Hour.ToString();
        }
    }
}
