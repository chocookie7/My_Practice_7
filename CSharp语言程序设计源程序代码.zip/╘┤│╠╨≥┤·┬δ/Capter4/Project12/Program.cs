﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入课程编号：");
            string couId = Console.ReadLine();
            Console.WriteLine("请输入课程名称：");
            string couName = Console.ReadLine();
            Console.WriteLine("请输入课程学分：");
            string couCredit = Console.ReadLine();
            Console.WriteLine("课程编号是：{0},课程名称是：{1},课程学分是：{2}", couId, couName, couCredit);
            Console.ReadKey();
        }
    }
}
