﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReader_Click(object sender, EventArgs e)
        {
            //创建数据库连接字符串
            string connStr = "server=.;database=SSMSDB1905;uid=sa;pwd=123456";
            //创建数据库连接对象
            SqlConnection conn = new SqlConnection(connStr);
            //打开数据库
            conn.Open();
            //创建命令对象
            SqlCommand comm = new SqlCommand();
            comm.Connection = conn;
            comm.CommandText = "select *from tbUserInfo  ";
            //执行命令并将结果存储到SqlDatareader对象中
            SqlDataReader sdr = comm.ExecuteReader();
            //将SqlDataReader对象的信息一条一条读到列表框中
            lstShow.Items .Add (string.Format("编号\t姓名\t密码\t用户类型"));
            while (sdr.Read())
            {
                lstShow.Items.Add(string.Format("{0}\t{1}\t{2}\t{3}", sdr[0], sdr[1], sdr[2], sdr[3]));
            }
            //关闭数据库
            conn.Close();
        }
    }
}
