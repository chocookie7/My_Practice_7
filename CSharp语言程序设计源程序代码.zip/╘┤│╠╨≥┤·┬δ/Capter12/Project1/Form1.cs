﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //在窗体的所有事件之外定义数据库连接
        static string conStr = "server=.;database=SSMSDB1905;uid=sa;pwd=123456";
        SqlConnection conn = new SqlConnection(conStr);
        //窗体的加载事件实现在标签处显示当前数据库的状态信息
        private void Form1_Load(object sender, EventArgs e)
        {
            lblShow.Text = "当前数据库连接状态是：" + conn.State.ToString();
        }
        //[打开连接]按钮的单击事件
        private void btnOpen_Click(object sender, EventArgs e)
        {
            conn.Open();
            lblShow.Text = "当前数据库连接状态是：" + conn.State.ToString();
        }
        //[关闭连接]按钮的单击事件
        private void btnClose_Click(object sender, EventArgs e)
        {
            conn.Close();
            lblShow.Text= "当前数据库连接状态是：" + conn.State.ToString();
        }   
    }
}
