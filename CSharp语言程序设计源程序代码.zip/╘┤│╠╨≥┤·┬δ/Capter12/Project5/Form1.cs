﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义数据库连接字符串
        string constr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        private void Form1_Load(object sender, EventArgs e)
        {
            //在窗体加载事件中加载用户信息表中的数据信息
            using (SqlConnection conn = new SqlConnection(constr))
            {
                //定义SQL语句
                string sql = "select ID as '用户编号',UserName as '用户姓名',UserPwd as '用户密码',UserType '用户类型' from tbUserInfo  ";
                //创建SaqDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建一个DataTable表
                DataTable dt = new DataTable();
                //调用SaqDataAdapter对象da的填充方法Fill()
                da.Fill(dt);
                //设置dataGridView1控件的数据源并绑定数据
                dataGridView1.DataSource = dt;    
            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            //添加按钮的单击事件实现输入的数据添加到数据表中
            using (SqlConnection conn = new SqlConnection(constr))
            {
                //定义SQL语句
                string sql = "select ID as '用户编号',UserName as '用户姓名',UserPwd as '用户密码',UserType '用户类型' from tbUserInfo ";
                //创建SaqDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建SqlCommandBuilder对象，根据SqlDataAdapter对象的GetInsertCommand方法为SqlDataAdapter对象生成InsertCommand方法，从而调用DataAdapter对象的Update方法更新数据库
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                //创建DataTable对象
                DataTable dt = new DataTable();
                //调用SqlDataAdapter对象的填充方法将数据库中数据表填充在DataTable对象dt中
                da.Fill(dt);
                //获取用户编号焦点
                this.txtNo.Focus();
                //创建数据行对象
                DataRow row = dt.NewRow();
                //为数据行中每列赋上前台文本框的输入值
                row[0] = this.txtNo.Text.Trim();
                row[1] = this.txtName.Text.Trim();
                row[2] = this.txtPwd.Text.Trim();
                row[3] = this.txtType.Text.Trim();
                //将创建的数据行添加到DataTable对象中
                dt.Rows.Add(row);
                //更新数据表
                da.Update(dt);
                //重新绑定dataGridView1对象的数据源
                dataGridView1.DataSource = dt;
                MessageBox.Show("添加一个用户信息成功！");
            }
        }
    }
}
