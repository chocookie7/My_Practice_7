﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project7
{
    public partial class Form1 : Form
    {
        public Form1( )
        {
            InitializeComponent();                   
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据连接对象
        SqlConnection conn = new SqlConnection(conStr);
        private void Form1_Load(object sender, EventArgs e)//窗体加载时调用加载专业数据表方法DataGridView()实现专业数据在数据绑定控件中显示
        {     
            DataGridViewBind(); 
        }

        public void DataGridViewBind()//定义加载专业数据表的方法DataGridViewBind()
        {
            //打开数据库
            conn.Open();
            //定义SQl语句
            string sql = "select SpecNo as '专业编号',SpecName as '专业名称',SpecRemark as '专业描述' from tbSpecInfo ";
            //创建SqlDataAdapter对象
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            //创建DataTable对象
            DataTable dt = new DataTable();
            //调用SqlDataAdapter对象的填充方法将数据表数据填充到DataTable对象中
            da.Fill(dt);
            conn.Close();
            //设置数据绑定控件DataGridView的数据源
            dataGridView1.DataSource = dt;           
        }
        //程序运行，dataGridView1数据绑定控件显示专业信息表的数据信息，双击行标题，则将该行数据加载到对应的文本框中
        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = new DataGridViewRow();
            row = dataGridView1.CurrentRow;
            txtSpecNo.Text = row.Cells["专业编号"].Value.ToString();
            txtSpecName.Text = row.Cells["专业名称"].Value.ToString();
            rtbSpecRemark.Text = row.Cells["专业描述"].Value.ToString();
        }
        public  void btnSpecUpdate_Click(object sender, EventArgs e)//更新按钮的单击事件完成数据表的更新
        {
           
            conn.Open();
            string sql = "update tbSpecInfo set SpecNo ='"+txtSpecNo.Text +"',SpecName ='"+txtSpecName .Text +"',SpecRemark ='"+rtbSpecRemark .Text +"'where SpecID ='"+txtSpecNo .Text +"'";
            SqlCommand comm = new SqlCommand(sql,conn);
            int n=comm.ExecuteNonQuery();
            conn.Close ();
            if (n == 1) //执行comm对象的ExecuteNonQuery()方法，成功返回1，否则返回0
            {
                MessageBox.Show("修改成功！");
                DataGridViewBind();  
            }
            else
            {
                MessageBox.Show("修改失败！");
            }
              
        }   
    }
}
