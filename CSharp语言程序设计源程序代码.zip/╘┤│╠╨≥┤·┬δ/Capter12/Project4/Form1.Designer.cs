﻿namespace Project4
{
    partial class frmSpec
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSpecName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAddSpec = new System.Windows.Forms.Button();
            this.lstShow = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtSpecName
            // 
            this.txtSpecName.Location = new System.Drawing.Point(68, 12);
            this.txtSpecName.Name = "txtSpecName";
            this.txtSpecName.Size = new System.Drawing.Size(100, 21);
            this.txtSpecName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "专业名称";
            // 
            // btnAddSpec
            // 
            this.btnAddSpec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddSpec.Location = new System.Drawing.Point(187, 10);
            this.btnAddSpec.Name = "btnAddSpec";
            this.btnAddSpec.Size = new System.Drawing.Size(91, 25);
            this.btnAddSpec.TabIndex = 6;
            this.btnAddSpec.Text = "添     加";
            this.btnAddSpec.UseVisualStyleBackColor = true;
            this.btnAddSpec.Click += new System.EventHandler(this.btnAddSpec_Click);
            // 
            // lstShow
            // 
            this.lstShow.FormattingEnabled = true;
            this.lstShow.ItemHeight = 12;
            this.lstShow.Location = new System.Drawing.Point(14, 41);
            this.lstShow.Name = "lstShow";
            this.lstShow.Size = new System.Drawing.Size(264, 136);
            this.lstShow.TabIndex = 7;
            // 
            // frmSpec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 189);
            this.Controls.Add(this.lstShow);
            this.Controls.Add(this.btnAddSpec);
            this.Controls.Add(this.txtSpecName);
            this.Controls.Add(this.label2);
            this.Name = "frmSpec";
            this.Text = "添加专业信息";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSpecName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddSpec;
        private System.Windows.Forms.ListBox lstShow;
    }
}

