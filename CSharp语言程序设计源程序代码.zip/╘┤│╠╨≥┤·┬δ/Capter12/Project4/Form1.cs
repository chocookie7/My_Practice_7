﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4
{
    public partial class frmSpec : Form
    {
        //创建DataTable类对象，其数据表名为tbSpecInfo
        private DataTable dt = new DataTable("tbspecInfo");
        public frmSpec() //在窗体初始化过程中创建专业编号、专业名称、专业描述列
        {
            InitializeComponent();
            //创建专业编号列，列名为SpecNo，数据类型是整型
            DataColumn SpecNo = new DataColumn("SpecNo", typeof(int));
            //将专业编号列加入到DataTable对象中
            dt.Columns.Add(SpecNo);
            //创建专业名称列，列名为SpecName，数据类型是字符串类型
            DataColumn SpecName = new DataColumn("SpecName", typeof(string));
            //将专业名称列加入到DataTable对象中
            dt.Columns.Add(SpecName);
            //创建专业描述列，列名为SpecRemark，数据类型是字符串类型
            DataColumn SpecRemark = new DataColumn("SpecRemark", typeof(string));
            //将专业名称列加入到DataTable对象中
            dt.Columns.Add(SpecRemark);
        }    
        private void btnAddSpec_Click(object sender, EventArgs e)//窗体界面[添加]按钮单击事件
        {
            //向DataTable中添加一行，创建DataRow对象
            DataRow dr = dt.NewRow();
            //添加专业名称列的值
            dr["SpecName"] = txtSpecName.Text;
            //将DataRow对象行添加到DataTable对象中
            dt.Rows.Add(dr);
            //设置ListBox控件中的数据源DataSource属性
            lstShow.DataSource = dt;
            //设置在ListBox控件中显示的列
            lstShow.DisplayMember = dt.Columns["SpecName"].ToString();
                   
        }
    }
}
