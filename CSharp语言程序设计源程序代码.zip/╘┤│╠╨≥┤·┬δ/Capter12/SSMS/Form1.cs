﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SSMS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
        SqlConnection conn = new SqlConnection(conStr);
        //定义绑定数据方法
        private void dataGridViewStudent()
        {
            conn.Open();
            
            //定义Sql语句
            string sql = "select *from tbStudent ";
            //创建DataAdapter对象
            SqlDataAdapter da = new SqlDataAdapter(sql,conn);
            //创建DataTable对象
            DataTable dt = new DataTable();
            //填充数据表
            da.Fill(dt);
            conn.Close();
            //设置DataGridView数据视图控件的数据源
            dgvStudent.DataSource = dt;
            //设置列标题
            dgvStudent.Columns[0].HeaderText = "学号";
            dgvStudent.Columns[1].HeaderText = "姓名";
            dgvStudent.Columns[2].HeaderText = "性别";
            dgvStudent.Columns[3].HeaderText = "年龄";
            dgvStudent.Columns[4].HeaderText = "专业";
            dgvStudent.Columns[5].HeaderText = "班级";
            dgvStudent.Columns[6].HeaderText = "电话";
            dgvStudent.Columns[7].HeaderText = "地址";    
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridViewStudent();
        }
        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            try 
            {
            //打开数据库
            conn.Open();
            //定义SQL语句
            string sql = "select stuNo as '学号',stuName as '姓名',stuSex as '性别',stuAge as '年龄',stuSpec as '专业',stuClass as '班级',stuPhone as '电话',stuAddress as '地址' from tbStudent ";
            //创建SqlDataAdapter对象
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            //创建SqlCommandBuilder对象，根据SqlDataAdapter对象的GetInsertCommand方法为SqlDataAdapter对象生成InsertCommand方法，从而调用DataAdapter对象的Update方法更新数据库
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            //创建DataTable对象
             DataTable dt = new DataTable();
            //调用SqlDataAdapter对象的填充方法将数据库中数据表填充在DataTable对象dt中
             da.Fill(dt);
            //获取用户编号焦点
             this.txtstuNo.Focus();
             //创建数据行对象
             DataRow row = dt.NewRow();
            //为数据行中每列赋上前台列表框的选择值或多行文本框的输入值
                row[0] = this.txtstuNo .Text .ToString();
                row[1] = this.txtstuName .Text .ToString();
                row[2] = this.cmbstuSex .SelectedItem.ToString();
                row[3] = this.txtstuAge .Text.ToString ();
                row[4]=this.cmbstuSpec .SelectedItem .ToString ();
                row[5]=this.cmbstuClass .SelectedItem .ToString ();
                row[6]=this.txtstuPhone .Text .ToString ();
                row [7]=this.txtstuAddress .Text .ToString ();
             //将创建的数据行添加到DataTable对象中
             dt.Rows.Add(row);
             //更新数据表
             da.Update(dt);
             //重新绑定dataGridView1对象的数据源
             MessageBox.Show("添加一个学生信息成功！");
             dgvStudent.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("添加失败！" + ex.Message);
            }
            finally
            {
                if (conn != null) { conn.Close(); }
            }
        }
        //按学号查询学生信息
        private void btnstuQuery_Click(object sender, EventArgs e)
        {
            try
            {
                //打开数据库
                conn.Open();
                //定义按学号查询的SQL语句
                string sql = "select *from tbStudent where  stuNo ='"+txtstuNo .Text +"'";
                //创建DataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataTable对象
                DataSet ds = new DataSet();
                //调用填充数据表方法
                da.Fill(ds);
                //设置数据源
                dgvStudent.DataSource = ds.Tables[0];
            }
            catch( Exception ex)
            {
                MessageBox.Show("没找到指定学号的学生!" + ex.Message );
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }   
    }
}
