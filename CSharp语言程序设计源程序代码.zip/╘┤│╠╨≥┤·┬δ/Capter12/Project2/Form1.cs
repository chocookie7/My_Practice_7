﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //1.定义数据库连接字符串
        static string connStr = "server=.;database=SSMSDB1905;uid=sa;pwd=123456";
        //2.创建数据库连接对象
        SqlConnection conn = new SqlConnection(connStr);
        //窗体界面[登录]按钮单击事件
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //3.打开数据库
            conn.Open();
            //4.编写SQL命令。采用拼接字符串方式，用窗体上文本框输入的用户名、密码字符串作为sql语句中的用户名和密码
            string sql = "select count(*) from tbUserInfo where UserName ='"+txtName .Text +"'and UserPwd ='"+txtPwd .Text +"'";
            //5.创建命令对象
            SqlCommand comm = new SqlCommand(sql, conn);
            //6.执行命令，调用命令对象中的ExecuteScalar()方法并将返回结果赋给整型变量n
            int n =Convert .ToInt32 ( comm.ExecuteScalar());
            //7.判断返回值n是否大于0，若大于0，则说明登录成功，并弹出登录成功的消息框；否则登录失败
            if (n >= 1)
            {
                MessageBox.Show("登录成功！");
            }
            else
            {
                MessageBox.Show("登录失败!");
            }
        }
        //窗体界面[取消]按钮单击事件
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
