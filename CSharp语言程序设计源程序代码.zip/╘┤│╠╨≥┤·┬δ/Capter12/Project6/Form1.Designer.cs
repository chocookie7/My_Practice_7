﻿namespace Project6
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSpecNo = new System.Windows.Forms.TextBox();
            this.txtSpecName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rtbSpecRemark = new System.Windows.Forms.RichTextBox();
            this.btnSpecAdd = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 8);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(334, 142);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "专业编号";
            // 
            // txtSpecNo
            // 
            this.txtSpecNo.Location = new System.Drawing.Point(80, 160);
            this.txtSpecNo.Name = "txtSpecNo";
            this.txtSpecNo.Size = new System.Drawing.Size(72, 21);
            this.txtSpecNo.TabIndex = 2;
            // 
            // txtSpecName
            // 
            this.txtSpecName.Location = new System.Drawing.Point(242, 160);
            this.txtSpecName.Name = "txtSpecName";
            this.txtSpecName.Size = new System.Drawing.Size(72, 21);
            this.txtSpecName.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(183, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "专业名称";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "专业描述";
            // 
            // rtbSpecRemark
            // 
            this.rtbSpecRemark.Location = new System.Drawing.Point(81, 189);
            this.rtbSpecRemark.Name = "rtbSpecRemark";
            this.rtbSpecRemark.Size = new System.Drawing.Size(152, 46);
            this.rtbSpecRemark.TabIndex = 6;
            this.rtbSpecRemark.Text = "";
            // 
            // btnSpecAdd
            // 
            this.btnSpecAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpecAdd.Location = new System.Drawing.Point(244, 192);
            this.btnSpecAdd.Name = "btnSpecAdd";
            this.btnSpecAdd.Size = new System.Drawing.Size(68, 23);
            this.btnSpecAdd.TabIndex = 7;
            this.btnSpecAdd.Text = "添  加";
            this.btnSpecAdd.UseVisualStyleBackColor = true;
            this.btnSpecAdd.Click += new System.EventHandler(this.btnSpecAdd_Click);
            // 
            // btnReset
            // 
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReset.Location = new System.Drawing.Point(242, 220);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(68, 23);
            this.btnReset.TabIndex = 8;
            this.btnReset.Text = "重  置";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 247);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSpecAdd);
            this.Controls.Add(this.rtbSpecRemark);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSpecName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSpecNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "添加数据到专业信息表中";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSpecNo;
        private System.Windows.Forms.TextBox txtSpecName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rtbSpecRemark;
        private System.Windows.Forms.Button btnSpecAdd;
        private System.Windows.Forms.Button btnReset;
    }
}

