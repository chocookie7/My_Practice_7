﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static  string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据连接对象
        SqlConnection conn = new SqlConnection(conStr);

        private void Form1_Load(object sender, EventArgs e)//窗体的加载事件实现专业信息表数据的显示
        {
            //打开数据库
            conn.Open();
            //定义SQl语句
            string sql = "select SpecNo as '专业编号',SpecName as '专业名称',SpecRemark as '专业描述' from tbSpecInfo ";
            //创建SqlDataAdapter对象
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            //创建DataTable对象
            DataTable dt = new DataTable();
            //调用SqlDataAdapter对象的填充方法将数据表数据填充到DataTable对象中
            da.Fill(dt);
            conn.Close();
            //设置数据绑定控件DataGridView的数据源
            dataGridView1.DataSource = dt;           
        }

        private void btnSpecAdd_Click(object sender, EventArgs e)//添加按钮事件实现界面文本框输入信息插入到专业信息表中
        {
            try
            {
                //打开数据库
                conn.Open();
                //定义向数据表中插入一个信息的数据
                string sql = "insert into tbSpecInfo values('"+txtSpecNo .Text +"','"+txtSpecName .Text +"','"+rtbSpecRemark .Text+ "')";
                //创建SqlCommand命令对象
                SqlCommand comm = new SqlCommand(sql, conn);
                //调用命令对象的ExecuteNonQuery方法
                comm.ExecuteNonQuery();
                MessageBox.Show("插入一条记录成功！");
                //创建SqlDataAdapter对象，刷新数据绑定控件DataGridView
                SqlDataAdapter da = new SqlDataAdapter("select SpecNo as '专业编号',SpecName as '专业名称',SpecRemark as '专业描述' from tbSpecInfo", conn);
                //创建DataTable对象
                DataTable dt = new DataTable();
                //调用SqlDataAdapter对象的填充方法将数据表数据填充到DataTable对象中
                da.Fill(dt);
                conn.Close();
                //设置数据绑定控件DataGridView的数据源
                dataGridView1.DataSource = dt;  
            }
            catch
            {
                MessageBox.Show("插入一条记录失败！");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)//重置按钮事件实现对界面文本框中信息的清空
        {
            txtSpecNo.Text = "";
            txtSpecName.Text = "";
            rtbSpecRemark.Text = "";
        }
    }
}
