﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据连接对象
        SqlConnection conn = new SqlConnection(conStr);
        private void Form1_Load(object sender, EventArgs e)
        {
            DataGridViewBind();
        }
        public void DataGridViewBind()//定义加载专业数据表的方法DataGridViewBind()
        {
            //打开数据库
            conn.Open();
            //定义SQl语句
            string sql = "select SpecNo as '专业编号',SpecName as '专业名称',SpecRemark as '专业描述' from tbSpecInfo ";
            //创建SqlDataAdapter对象
            using (SqlDataAdapter da = new SqlDataAdapter(sql, conn))
            {
                //创建DataTable对象
                DataTable dt = new DataTable();
                //调用SqlDataAdapter对象的填充方法将数据表数据填充到DataTable对象中
                da.Fill(dt);
                conn.Close();
                //设置数据绑定控件DataGridView的数据源
                dataGridView1.DataSource = dt;
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //定义数据行对象
            DataGridViewRow row;
            if (dataGridView1.CurrentRow != null) //判断是否选定行,选定单元格所在行不为空,说明已选定了行
            {
                row = dataGridView1.CurrentRow; //获取选定单元格所在的行
                string sql = "select *from tbSpecInfo where SpecNo =@SpecID"; //按专业编号查询行信息,其中"专业编号"是设置的参数
                conn.Open();
                SqlCommand comm = new SqlCommand(sql, conn);
                comm.Parameters.Add(new SqlParameter ("@SpecID",row .Cells ["专业编号"].Value .ToString ()));
                SqlDataReader read = comm.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    string sqld="delete from tbSpecInfo where SpecNo =@delSpecID";
                    comm.Parameters .Add (new SqlParameter ("@delspecID",row.Cells ["专业编号"].Value .ToString ()));
                    comm.CommandText =sqld;
                    //弹出对话框,询问是否删除,单击[确定],则删除,单击[取消]则放弃删除
                    DialogResult drl = MessageBox.Show("是否删除该行?", "确定", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (drl == DialogResult.OK)
                    {
                        comm.ExecuteNonQuery();
                    }
                    conn.Close();
                     //删除选定行后,刷新dataGridView1数据绑定控件并显示删除行记录的数据信息
                    DataGridViewBind();
                }
                else
                {
                   MessageBox .Show ("该专业下有班级,请先删除班级后再删除专业!");    
                }
            }    
        }      
    }
}
