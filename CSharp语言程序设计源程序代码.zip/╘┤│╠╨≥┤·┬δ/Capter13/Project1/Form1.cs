﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义数据库连接字符串
       static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
       SqlConnection conn = new SqlConnection(conStr);
        

        private void Form1_Load(object sender, EventArgs e)
        {
            //调用加载数据到ComboBox控件的方法
            GetLoadComboBox();
        }
        //定义一个加载数据到ComboBox控件的方法
        private void GetLoadComboBox()
        {
            try
            {
                 //打开数据库
            conn.Open();
            //定义SQL语句
            string sql = "select *from tbCourseInfo ";
            //创建SqlDataAdapter对象
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            //创建DataSet对象
            DataSet ds = new DataSet();
            //使用SqlDataAdapter对象da将查询结果填充到DataSet对象ds中
            da.Fill(ds);
            //设置组合框的DataSource属性
            cmbCourNo.DataSource = ds.Tables[0];
            cmbCourName.DataSource = ds.Tables[0];
            //设置组合框的DisplayMember
            cmbCourNo.DisplayMember = "No";
            cmbCourName.DisplayMember = "Name";
            //设置组合框ValueMember
            cmbCourNo.ValueMember = "couNo";
            cmbCourName.ValueMember = "couName";
            }
            catch(Exception ex)
            {
                MessageBox.Show("加载数据出现错误！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    //关闭数据库
                    conn.Close();
                }
            }
        }
        private void btnChoice_Click(object sender, EventArgs e)
        {
            string  couNo=cmbCourNo.SelectedValue .ToString ();
            string couName=cmbCourName .SelectedValue.ToString ();
            lblShow .Text =string.Format ("选择的课程编号是：{0}，课程名称是：{1}",couNo ,couName );
        }
    }
}
