﻿namespace Project1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cmbCourNo = new System.Windows.Forms.ComboBox();
            this.cmbCourName = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnChoice = new System.Windows.Forms.Button();
            this.lblShow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "课程编号";
            // 
            // cmbCourNo
            // 
            this.cmbCourNo.FormattingEnabled = true;
            this.cmbCourNo.Location = new System.Drawing.Point(84, 25);
            this.cmbCourNo.Margin = new System.Windows.Forms.Padding(4);
            this.cmbCourNo.Name = "cmbCourNo";
            this.cmbCourNo.Size = new System.Drawing.Size(84, 23);
            this.cmbCourNo.TabIndex = 1;
            // 
            // cmbCourName
            // 
            this.cmbCourName.FormattingEnabled = true;
            this.cmbCourName.Location = new System.Drawing.Point(242, 25);
            this.cmbCourName.Margin = new System.Windows.Forms.Padding(4);
            this.cmbCourName.Name = "cmbCourName";
            this.cmbCourName.Size = new System.Drawing.Size(144, 23);
            this.cmbCourName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(170, 29);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "课程名称";
            // 
            // btnChoice
            // 
            this.btnChoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChoice.Location = new System.Drawing.Point(393, 22);
            this.btnChoice.Name = "btnChoice";
            this.btnChoice.Size = new System.Drawing.Size(101, 27);
            this.btnChoice.TabIndex = 4;
            this.btnChoice.Text = "选   择";
            this.btnChoice.UseVisualStyleBackColor = true;
            this.btnChoice.Click += new System.EventHandler(this.btnChoice_Click);
            // 
            // lblShow
            // 
            this.lblShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShow.Location = new System.Drawing.Point(29, 60);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(464, 112);
            this.lblShow.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 194);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.btnChoice);
            this.Controls.Add(this.cmbCourName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbCourNo);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbCourNo;
        private System.Windows.Forms.ComboBox cmbCourName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnChoice;
        private System.Windows.Forms.Label lblShow;
    }
}

