﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project4
{
    public partial class frmSelect : Form
    {
        public frmSelect()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
        SqlConnection conn = new SqlConnection(conStr);
        //定义绑定数据表信息到dgvCourseInfo控件的方法GetdgvCourseInfo()
        private void GetdgvCourseInfo()
        {
            try
            {
                conn.Open();// 打开数据库
                //定义SQL语句
                string sql = "select *from tbCourseInfo ";
                //创建SqlDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataSet对象
                DataSet ds = new DataSet();
                //调用SqlDataAdapter对象da的填充方法Fill()，将数据表数据填充到ds对象中
                da.Fill(ds);
                //设置dgvCourseInfo控件对象的数据源
                dgvCoureseInfo.DataSource = ds.Tables[0];
                //设置dgvCourseInfo控件的列标题
                dgvCoureseInfo.Columns[0].HeaderText = "课程编号";
                dgvCoureseInfo.Columns[1].HeaderText = "课程名称";
                dgvCoureseInfo.Columns[2].HeaderText = "课程学分";
                dgvCoureseInfo.Columns[3].HeaderText = "课程说明";     
            }
            catch (Exception ex)
            {
                MessageBox.Show("查询失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }            
        }
        //窗体加载事件调用GetdgvCourseInfo()方法，实现数据绑定并显示
        private void Form1_Load(object sender, EventArgs e)
        { 
            GetdgvCourseInfo();
        }
        //单击窗体[按课程名查询]，查询结果重新绑定到DataGridVieew控件并显示
        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                //打开数据库
                conn.Open();
                //定义模糊查询的sql语句
                string sql = "select *from tbCourseInfo where couName like '{0}'";
                //填充占位符
                sql = string.Format(sql, cmbcouName.SelectedItem.ToString());
                //创建DataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataSet对象
                DataSet ds = new DataSet();
                //使用SqlDataAdaptr对象da查询结果填充到DataSet对象ds中
                da.Fill(ds);
                dgvCoureseInfo.DataSource = ds.Tables[0];        
            }
            catch (Exception ex)
            {
                MessageBox.Show("查询出错！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    //关闭数据库
                    conn.Close();
                }
            }
        }

       
    }
}
