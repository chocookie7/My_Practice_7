﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project6
{
    public partial class frmDeleteCourse : Form
    {
        public frmDeleteCourse()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
        SqlConnection conn = new SqlConnection(conStr);
        /// <summary>
        ///  定义绑定数据表信息到dgvCourseInfo控件的方法GetdgvCourseInfo()
        /// </summary>
        private void GetdgvCourseIn()
        {
            try
            {
                //打开数据库
                conn.Open();
                //定义SQL语句
                string sql = "select couNo as '课程编号',couName as '课程名称',couScore as '课程学分',couRemark as '课程说明' from tbCourseInfo ";
                //创建SqlDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataTbale对象
                DataTable dt = new DataTable();
                //调用SqlDataAdapter 对象的填充方法
                da.Fill(dt);
                dgvCoureseInfo.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("数据绑定失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        /// <summary>
        /// 课程信息管理窗体的加载事件实现课程信息绑定到DataGridview控件上并显示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            GetdgvCourseIn();
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //定义数据行对象，获得删除行
            DataGridViewRow row;
            if (dgvCoureseInfo.CurrentRow != null)
            {
                row = dgvCoureseInfo.CurrentRow;
                //按课程编号查询
                string sql = "select *from tbCourseInfo where couNo=@No";
                conn.Open();
                SqlCommand comm = new SqlCommand(sql, conn);
                comm.Parameters.Add(new SqlParameter("@No", row.Cells["课程编号"].Value.ToString()));
                SqlDataReader read = comm.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    string sqldel = "delete from tbCourseInfo where couNo=@couNo";
                    comm.Parameters.Add(new SqlParameter("@couNo", row.Cells["课程编号"].Value.ToString()));
                    comm.CommandText = sqldel;
                    DialogResult drl = MessageBox.Show("是否删除选中行？课程编号是：" + row.Cells["课程编号"].Value.ToString(), "确定", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (drl == DialogResult.OK)
                    {
                        comm.ExecuteNonQuery();
                        MessageBox.Show("删除成功！课程编号：" + row.Cells["课程编号"].Value.ToString());
                    }
                    conn.Close();
                    GetdgvCourseIn();
                }
                else
                {
                    MessageBox.Show("课程有学生选学，先删除选学生！");
                }
            }
        }    
    }
}
