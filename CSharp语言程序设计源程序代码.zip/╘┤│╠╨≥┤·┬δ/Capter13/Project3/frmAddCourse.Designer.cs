﻿namespace Project3
{
    partial class frmAddCourse
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbcouNo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbcouName = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbcouScore = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rtbcouRemark = new System.Windows.Forms.RichTextBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.dgvCoureseInfo = new System.Windows.Forms.DataGridView();
            this.btnAddCourse = new System.Windows.Forms.Button();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoureseInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbcouNo
            // 
            this.cmbcouNo.FormattingEnabled = true;
            this.cmbcouNo.Items.AddRange(new object[] {
            "1001",
            "1002",
            "1003",
            "1004",
            "1017",
            "1021",
            "2001",
            "2002",
            "2003",
            "2004",
            "3001",
            "3002",
            "3003",
            "4001",
            "4002",
            "4003",
            "4004"});
            this.cmbcouNo.Location = new System.Drawing.Point(83, 20);
            this.cmbcouNo.Name = "cmbcouNo";
            this.cmbcouNo.Size = new System.Drawing.Size(130, 23);
            this.cmbcouNo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "课程编号";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "课程名称";
            // 
            // cmbcouName
            // 
            this.cmbcouName.FormattingEnabled = true;
            this.cmbcouName.Items.AddRange(new object[] {
            "大学计算机基础",
            "C语言程序设计",
            "数据库原理及应用",
            "计算机网络基础原理",
            "计算机组成原理",
            "操作系统原理",
            "数据结构",
            "JAVA语言程序设计",
            "C++程序设计",
            "C#程序设计",
            "JAVA Web应用开发技术",
            "ASP.NET应用开发技术"});
            this.cmbcouName.Location = new System.Drawing.Point(83, 49);
            this.cmbcouName.Name = "cmbcouName";
            this.cmbcouName.Size = new System.Drawing.Size(130, 23);
            this.cmbcouName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "课程学分";
            // 
            // cmbcouScore
            // 
            this.cmbcouScore.FormattingEnabled = true;
            this.cmbcouScore.Items.AddRange(new object[] {
            "1",
            "2",
            "2.5",
            "3",
            "3.5",
            "4"});
            this.cmbcouScore.Location = new System.Drawing.Point(83, 78);
            this.cmbcouScore.Name = "cmbcouScore";
            this.cmbcouScore.Size = new System.Drawing.Size(130, 23);
            this.cmbcouScore.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "课程说明";
            // 
            // rtbcouRemark
            // 
            this.rtbcouRemark.Location = new System.Drawing.Point(86, 111);
            this.rtbcouRemark.Name = "rtbcouRemark";
            this.rtbcouRemark.Size = new System.Drawing.Size(127, 90);
            this.rtbcouRemark.TabIndex = 7;
            this.rtbcouRemark.Text = "";
            // 
            // btnSelect
            // 
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Location = new System.Drawing.Point(9, 241);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(203, 33);
            this.btnSelect.TabIndex = 8;
            this.btnSelect.Text = "查    询";
            this.btnSelect.UseVisualStyleBackColor = true;
            // 
            // dgvCoureseInfo
            // 
            this.dgvCoureseInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCoureseInfo.Location = new System.Drawing.Point(224, 20);
            this.dgvCoureseInfo.Name = "dgvCoureseInfo";
            this.dgvCoureseInfo.RowTemplate.Height = 27;
            this.dgvCoureseInfo.Size = new System.Drawing.Size(529, 329);
            this.dgvCoureseInfo.TabIndex = 9;
            // 
            // btnAddCourse
            // 
            this.btnAddCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCourse.Location = new System.Drawing.Point(9, 204);
            this.btnAddCourse.Name = "btnAddCourse";
            this.btnAddCourse.Size = new System.Drawing.Size(203, 33);
            this.btnAddCourse.TabIndex = 10;
            this.btnAddCourse.Text = "添    加";
            this.btnAddCourse.UseVisualStyleBackColor = true;
            this.btnAddCourse.Click += new System.EventHandler(this.btnAddCourse_Click);
            // 
            // btnModify
            // 
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModify.Location = new System.Drawing.Point(9, 278);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(203, 33);
            this.btnModify.TabIndex = 11;
            this.btnModify.Text = "修    改";
            this.btnModify.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Location = new System.Drawing.Point(9, 316);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(203, 33);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "删    除";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 370);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.btnAddCourse);
            this.Controls.Add(this.dgvCoureseInfo);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.rtbcouRemark);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbcouScore);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbcouName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbcouNo);
            this.Name = "Form1";
            this.Text = "课程信息管理";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoureseInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbcouNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbcouName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbcouScore;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtbcouRemark;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.DataGridView dgvCoureseInfo;
        private System.Windows.Forms.Button btnAddCourse;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnDelete;
    }
}

