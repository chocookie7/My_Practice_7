﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project3
{
    public partial class frmAddCourse : Form
    {
        public frmAddCourse()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
        SqlConnection conn = new SqlConnection(conStr);
        //定义课程信息表绑定到dgvCoureseInfo控件的方法GetdgvCourseInfo()
        private void GetdgvCourseInfo()
        {
            try
            {
                conn.Open();// 打开数据库
                //定义SQL语句
                string sql = "select *from tbCourseInfo ";
                //创建SqlDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataSet对象
                DataSet ds = new DataSet();
                //调用SqlDataAdapter对象da的填充方法Fill()，将数据表数据填充到ds对象中
                da.Fill(ds);
                //设置dgvCourseInfo控件对象的数据源
                dgvCoureseInfo.DataSource = ds.Tables[0];
                //设置dgvCourseInfo控件的列标题
                dgvCoureseInfo.Columns[0].HeaderText = "课程编号";
                dgvCoureseInfo.Columns[1].HeaderText = "课程名称";
                dgvCoureseInfo.Columns[2].HeaderText = "课程学分";
                dgvCoureseInfo.Columns[3].HeaderText = "课程说明";               
            }
            catch (Exception ex)
            {
                MessageBox.Show("查询失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            GetdgvCourseInfo();
        }
        //添加按钮的单击事件完成在课程信息的添加
        private void btnAddCourse_Click(object sender, EventArgs e)
        {
            try 
            {
            //打开数据库
            conn.Open();
            //定义SQL语句
            string sql = "select couNo as '课程编号',couName as '课程名称',couScore as '课程学分',couRemark as '课程说明' from tbCourseInfo ";
            //创建SqlDataAdapter对象
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            //创建SqlCommandBuilder对象，根据SqlDataAdapter对象的GetInsertCommand方法为SqlDataAdapter对象生成InsertCommand方法，从而调用DataAdapter对象的Update方法更新数据库
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            //创建DataTable对象
             DataTable dt = new DataTable();
            //调用SqlDataAdapter对象的填充方法将数据库中数据表填充在DataTable对象dt中
             da.Fill(dt);
            //获取用户编号焦点
             this.cmbcouNo.Focus();
             //创建数据行对象
             DataRow row = dt.NewRow();
            //为数据行中每列赋上前台列表框的选择值或多行文本框的输入值
             row[0] = this.cmbcouNo.SelectedItem.ToString();
             row[1] = this.cmbcouName.SelectedItem.ToString();
             row[2] = this.cmbcouScore.SelectedItem.ToString();
             row[3] = this.rtbcouRemark.Text.Trim();
             //将创建的数据行添加到DataTable对象中
             dt.Rows.Add(row);
             //更新数据表
             da.Update(dt);
             MessageBox.Show("添加一个课程信息成功！");
             //重新绑定dataGridView1对象的数据源
             dgvCoureseInfo.DataSource = dt;
             
            }
            catch (Exception ex)
            {
                MessageBox.Show("添加失败！" + ex.Message);
            }
            finally
            {
                if (conn != null) { conn.Close(); }
            }
        }
    }
}
