﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SSMS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static string constr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        SqlConnection conn = new SqlConnection(constr);
        private void dataGridviewStudent()
        {
            try
            {
                conn.Open();
                string sql = "select *from tbStudent";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvStudent.DataSource = dt;
                dgvStudent.Columns[0].HeaderText = "学号";
                dgvStudent.Columns[1].HeaderText = "姓名";
                dgvStudent.Columns[2].HeaderText = "性别";
                dgvStudent.Columns[3].HeaderText = "年龄";
                dgvStudent.Columns[4].HeaderText = "专业";
                dgvStudent.Columns[5].HeaderText = "班级";
                dgvStudent.Columns[6].HeaderText = "电话";
                dgvStudent.Columns[7].HeaderText = "地址";
            }
            catch (Exception ex)
            {
                MessageBox.Show("修改学生信息失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridviewStudent();
        }

        private void dgvStudent_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //思想：创建数据视图控件行对象，将当前单元格所在行赋给该数据行对象，将该行对应列的值赋给相应的控件
            DataGridViewRow row = new DataGridViewRow();
            row = dgvStudent.CurrentRow;
            txtstuNo.Text = row.Cells[0].Value.ToString();
            txtstuName.Text = row.Cells[1].Value.ToString();
            cmbstuSex.Text = row.Cells[2].Value.ToString();
            txtstuAge.Text = row.Cells[3].Value.ToString();
            cmbstuSpec.Text = row.Cells[4].Value.ToString();
            cmbstuClass.Text = row.Cells[5].Value.ToString();
            txtstuPhone.Text = row.Cells[6].Value.ToString();
            txtstuAddress.Text = row.Cells[7].Value.ToString();
        }

        private void btnModifyStudent_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string sql = "update tbStudent set stuNo='"+txtstuNo .Text +"',stuName ='"+txtstuName .Text +"',stuSex ='"+cmbstuSex .Text +"',stuAge ='"+txtstuAge .Text+"'  ,stuSpec ='"+cmbstuSpec.Text  +"',stuClass ='"+cmbstuClass .Text +"',stuPhone ='"+txtstuPhone .Text +"',stuAddress ='"+txtstuAddress .Text +"' where stuNo ='"+txtstuNo .Text +"'";
                SqlCommand comm = new SqlCommand(sql, conn);
               int n= comm.ExecuteNonQuery();
               conn.Close();
               if (n == 1)
               {
                   MessageBox.Show("修改学生信息成功！");
                   dataGridviewStudent();
               }
            }
            catch (Exception ex)
            {
                MessageBox.Show("修改失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //定义数据行对象，获得删除行
            DataGridViewRow row;
            if (dgvStudent.CurrentRow != null)
            {
                row = dgvStudent.CurrentRow;
                //按课程编号查询
                string sql = "select *from tbStudent  where stuNo=@No";
                conn.Open();
                SqlCommand comm = new SqlCommand(sql, conn);
                comm.Parameters.Add(new SqlParameter("@No", row.Cells[0].Value.ToString()));
                SqlDataReader read = comm.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    string sqldel = "delete from tbStudent where stuNo=@stuNo";
                    comm.Parameters.Add(new SqlParameter("@stuNo", row.Cells[0].Value.ToString()));
                    comm.CommandText = sqldel;
                    DialogResult drl = MessageBox.Show("是否删除选中行？学号是：" + row.Cells[0].Value.ToString(), "确定", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (drl == DialogResult.OK)
                    {
                        comm.ExecuteNonQuery();
                        MessageBox.Show("删除成功！学号是：" + row.Cells[0].Value.ToString());
                    }
                    conn.Close();
                    dataGridviewStudent();
                }
                else
                {
                    MessageBox.Show("学生有成绩，先删除选成绩！");
                }
            }
        }
    }
}
