﻿namespace SSMS
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvStudent = new System.Windows.Forms.DataGridView();
            this.cmbstuClass = new System.Windows.Forms.ComboBox();
            this.cmbstuSpec = new System.Windows.Forms.ComboBox();
            this.cmbstuSex = new System.Windows.Forms.ComboBox();
            this.btnModifyStudent = new System.Windows.Forms.Button();
            this.txtstuAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtstuPhone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtstuAge = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtstuName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtstuNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvStudent
            // 
            this.dgvStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudent.Location = new System.Drawing.Point(250, 9);
            this.dgvStudent.Name = "dgvStudent";
            this.dgvStudent.RowTemplate.Height = 27;
            this.dgvStudent.Size = new System.Drawing.Size(574, 318);
            this.dgvStudent.TabIndex = 38;
            this.dgvStudent.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvStudent_RowHeaderMouseDoubleClick);
            // 
            // cmbstuClass
            // 
            this.cmbstuClass.FormattingEnabled = true;
            this.cmbstuClass.Items.AddRange(new object[] {
            "计科本1",
            "计科本2",
            "计科本3",
            "计科本4",
            "软工本1",
            "软工本2",
            "大数据本1",
            "大数据本2",
            "计网本1",
            "计网本2",
            "网工本1",
            "网工本2"});
            this.cmbstuClass.Location = new System.Drawing.Point(50, 174);
            this.cmbstuClass.Name = "cmbstuClass";
            this.cmbstuClass.Size = new System.Drawing.Size(185, 23);
            this.cmbstuClass.TabIndex = 37;
            // 
            // cmbstuSpec
            // 
            this.cmbstuSpec.FormattingEnabled = true;
            this.cmbstuSpec.Items.AddRange(new object[] {
            "计算机科学与技术",
            "软件工程",
            "计算机网络技术",
            "数据科学与大数据技术",
            "网络工程"});
            this.cmbstuSpec.Location = new System.Drawing.Point(50, 145);
            this.cmbstuSpec.Name = "cmbstuSpec";
            this.cmbstuSpec.Size = new System.Drawing.Size(185, 23);
            this.cmbstuSpec.TabIndex = 36;
            // 
            // cmbstuSex
            // 
            this.cmbstuSex.FormattingEnabled = true;
            this.cmbstuSex.Items.AddRange(new object[] {
            "男",
            "女"});
            this.cmbstuSex.Location = new System.Drawing.Point(51, 83);
            this.cmbstuSex.Name = "cmbstuSex";
            this.cmbstuSex.Size = new System.Drawing.Size(185, 23);
            this.cmbstuSex.TabIndex = 35;
            // 
            // btnModifyStudent
            // 
            this.btnModifyStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModifyStudent.Location = new System.Drawing.Point(17, 265);
            this.btnModifyStudent.Name = "btnModifyStudent";
            this.btnModifyStudent.Size = new System.Drawing.Size(218, 31);
            this.btnModifyStudent.TabIndex = 34;
            this.btnModifyStudent.Text = "修      改";
            this.btnModifyStudent.UseVisualStyleBackColor = true;
            this.btnModifyStudent.Click += new System.EventHandler(this.btnModifyStudent_Click);
            // 
            // txtstuAddress
            // 
            this.txtstuAddress.Location = new System.Drawing.Point(51, 233);
            this.txtstuAddress.Name = "txtstuAddress";
            this.txtstuAddress.Size = new System.Drawing.Size(185, 25);
            this.txtstuAddress.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 15);
            this.label8.TabIndex = 32;
            this.label8.Text = "地址";
            // 
            // txtstuPhone
            // 
            this.txtstuPhone.Location = new System.Drawing.Point(51, 202);
            this.txtstuPhone.Name = "txtstuPhone";
            this.txtstuPhone.Size = new System.Drawing.Size(185, 25);
            this.txtstuPhone.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 15);
            this.label7.TabIndex = 30;
            this.label7.Text = "电话";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 15);
            this.label6.TabIndex = 29;
            this.label6.Text = "班级";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 15);
            this.label5.TabIndex = 28;
            this.label5.Text = "专业";
            // 
            // txtstuAge
            // 
            this.txtstuAge.Location = new System.Drawing.Point(51, 113);
            this.txtstuAge.Name = "txtstuAge";
            this.txtstuAge.Size = new System.Drawing.Size(185, 25);
            this.txtstuAge.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 26;
            this.label4.Text = "年龄";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 25;
            this.label3.Text = "性别";
            // 
            // txtstuName
            // 
            this.txtstuName.Location = new System.Drawing.Point(51, 51);
            this.txtstuName.Name = "txtstuName";
            this.txtstuName.Size = new System.Drawing.Size(185, 25);
            this.txtstuName.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "姓名";
            // 
            // txtstuNo
            // 
            this.txtstuNo.Location = new System.Drawing.Point(51, 20);
            this.txtstuNo.Name = "txtstuNo";
            this.txtstuNo.Size = new System.Drawing.Size(185, 25);
            this.txtstuNo.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "学号";
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Location = new System.Drawing.Point(17, 302);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(218, 31);
            this.btnDelete.TabIndex = 39;
            this.btnDelete.Text = "删      除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 339);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dgvStudent);
            this.Controls.Add(this.cmbstuClass);
            this.Controls.Add(this.cmbstuSpec);
            this.Controls.Add(this.cmbstuSex);
            this.Controls.Add(this.btnModifyStudent);
            this.Controls.Add(this.txtstuAddress);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtstuPhone);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtstuAge);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtstuName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtstuNo);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "学生管理";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvStudent;
        private System.Windows.Forms.ComboBox cmbstuClass;
        private System.Windows.Forms.ComboBox cmbstuSpec;
        private System.Windows.Forms.ComboBox cmbstuSex;
        private System.Windows.Forms.Button btnModifyStudent;
        private System.Windows.Forms.TextBox txtstuAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtstuPhone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtstuAge;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtstuName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtstuNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDelete;
    }
}

