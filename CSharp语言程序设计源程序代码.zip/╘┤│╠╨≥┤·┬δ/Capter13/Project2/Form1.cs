﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
        SqlConnection conn = new SqlConnection(conStr);
        //定义加载数据表信息到dgvCourseInfo控件的方法
        private void GetdgvCourseInfo()
        {
            try
            {
                conn.Open();// 打开数据库
                //定义SQL语句
                string sql = "select *from tbCourseInfo ";
                //创建SqlDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataSet对象
                DataSet ds = new DataSet();
                //调用SqlDataAdapter对象da的填充方法Fill()，将数据表数据填充到ds对象中
                da.Fill(ds);
                //设置dgvCourseInfo控件对象的数据源
                dgvCoureseInfo.DataSource = ds.Tables [0]; 
                //设置dgvCourseInfo控件的列标题
                dgvCoureseInfo.Columns[0].HeaderText = "课程编号";
                dgvCoureseInfo.Columns[1].HeaderText = "课程名称";
                dgvCoureseInfo.Columns[2].HeaderText = "课程学分";
                dgvCoureseInfo.Columns[3].HeaderText = "课程说明";
                //设置dgvCourseInfo控件不允许添加行
                dgvCoureseInfo.AllowUserToAddRows = false;
                //设置dgvCourseInfo控件只允许选择单行
                dgvCoureseInfo.MultiSelect = false;
                //设置dgvCourseInfo控件是整行选中
                dgvCoureseInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch(Exception ex)
            {
                MessageBox.Show("查询失败！"+ex.Message );
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        //窗体加载事件调用GetdgvCourseInfo()方法实现数据加载并显示
        private void Form1_Load(object sender, EventArgs e)
        {
            GetdgvCourseInfo();
        }
    }
}
