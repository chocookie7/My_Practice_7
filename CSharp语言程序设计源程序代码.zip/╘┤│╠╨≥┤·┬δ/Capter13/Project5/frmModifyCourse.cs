﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project5
{
    public partial class frmModifyCourse : Form
    {
        public frmModifyCourse()
        {
            InitializeComponent();
        }
        //定义静态数据库连接字符串
        static string conStr = "server=.;uid=sa;pwd=123456;database=SSMSDB1905";
        //创建数据库连接对象
        SqlConnection conn = new SqlConnection(conStr);
        /// <summary>
        ///  定义绑定数据表信息到dgvCourseInfo控件的方法GetdgvCourseInfo()
        /// </summary>
        private void GetdgvCourseInfo()
        {
            try
            {
                conn.Open();// 打开数据库
                //定义SQL语句
                string sql = "select *from tbCourseInfo ";
                //创建SqlDataAdapter对象
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                //创建DataSet对象
                DataTable dt = new DataTable();
                //调用SqlDataAdapter对象da的填充方法Fill()，将数据表数据填充到ds对象中
                da.Fill(dt);
                //设置dgvCourseInfo控件对象的数据源
                dgvCoureseInfo.DataSource = dt;
                //设置dgvCourseInfo控件的列标题
                dgvCoureseInfo.Columns[0].HeaderText = "课程编号";
                dgvCoureseInfo.Columns[1].HeaderText = "课程名称";
                dgvCoureseInfo.Columns[2].HeaderText = "课程学分";
                dgvCoureseInfo.Columns[3].HeaderText = "课程说明";
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("数据绑定失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }  
        /// <summary>
        /// 窗体加载事件调用GetdgvCourseInfo()方法，实现数据绑定并显示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            GetdgvCourseInfo();
        }
        /// <summary>
        /// 单击窗体Form1上的[修改]按钮，完成对选中行以课程编号为条件进行课程信息的修改操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                //打开数据库
                conn.Open();
                //编写SQL语句
                string sql = "update tbCourseInfo set couNo ='"+cmbcouNo.Text  +"',couName ='"+cmbcouName.Text   +"',couScore ='"+cmbcouScore.Text  +"',couRemark ='"+rtbcouRemark .Text +"'where couNo ='"+cmbcouNo.Text+"' ";
                //创建命令对象
                SqlCommand comm = new SqlCommand(sql, conn);
                //执行命令
                int n = comm.ExecuteNonQuery();
                conn.Close();
                //判断是否执行成功，并弹出相应的消息框
                if (n == 1)
                {
                    MessageBox.Show("修改成功！");
                    GetdgvCourseInfo();
                }
                else
                {
                    MessageBox.Show("修改失败！");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("修改失败！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }   
        /// <summary>
        /// 鼠标双击行标题，将选中行字段加载到ComboBox的课程编号、课程名称、课程学分、课程说明下拉列表框中
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvCoureseInfo_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row=new DataGridViewRow (); //创建一个数据行对象
            row=dgvCoureseInfo.CurrentRow;       //获取鼠标单击单元格的数据行
            cmbcouNo.Text = row.Cells[0].Value .ToString();
            cmbcouName.Text  = row.Cells[1].Value .ToString();
            cmbcouScore.Text  = row.Cells[2].Value .ToString();
            rtbcouRemark.Text = row.Cells[3].Value .ToString().Trim ();
        }   
    }
}
