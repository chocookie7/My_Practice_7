﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            int num1 = 23;
            int num2 = 36;
            lblShow.Text = "两数交换前：";
            lblShow.Text += "\n" + string.Format("num1={0};num2={1}", num1, num2);
            lblShow.Text += "\n" + "两数交换后：";
            //设计两数交换的算法
            int temp;
            temp = num1;
            num1 = num2;
            num2 = temp;
            lblShow.Text += "\n" + string.Format("num1={0};num2={1}", num1, num2);
        }
    }
}
