﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowGrade_Click(object sender, EventArgs e)
        {
            //定义一个双精度型成绩变量，用于接收前台文本框输入的学生成绩分数；定义字符串变量用于显示成绩等级
            double score = Convert .ToDouble ( txtScore.Text);
            string grade = string.Empty; //等级字符串初始值为空
            //运用多分支对成绩变量的值进行判断，90分及以上为优，80分及以上为良好，70分及以上为中,60分及以上为及格，否则为不及格。
            if (score >= 90)
            {
                grade = "优秀";
            }
            else if (score >= 80)
            {
                grade = "良好";
            }
            else if (score >= 70)
            {
                grade = "中等";
            }
            else if (score >= 60)
            {
                grade = "及格";
            }
            else
            {
                grade = "不及格";
            }
            lblShow.Text = string.Format("你输入的成绩是：{0}，对应的等级是：{1}", score, grade);
        }
    }
}
