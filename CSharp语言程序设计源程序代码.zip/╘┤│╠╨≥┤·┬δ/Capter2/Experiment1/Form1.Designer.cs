﻿namespace Experiment1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.btnJudging = new System.Windows.Forms.Button();
            this.lblShow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "年份";
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(60, 21);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(161, 25);
            this.txtYear.TabIndex = 1;
            // 
            // btnJudging
            // 
            this.btnJudging.Location = new System.Drawing.Point(243, 19);
            this.btnJudging.Name = "btnJudging";
            this.btnJudging.Size = new System.Drawing.Size(105, 32);
            this.btnJudging.TabIndex = 2;
            this.btnJudging.Text = "判断";
            this.btnJudging.UseVisualStyleBackColor = true;
            this.btnJudging.Click += new System.EventHandler(this.btnJudging_Click);
            // 
            // lblShow
            // 
            this.lblShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShow.Location = new System.Drawing.Point(17, 66);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(339, 90);
            this.lblShow.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 181);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.btnJudging);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "判断年份是否是闰年";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Button btnJudging;
        private System.Windows.Forms.Label lblShow;
    }
}

