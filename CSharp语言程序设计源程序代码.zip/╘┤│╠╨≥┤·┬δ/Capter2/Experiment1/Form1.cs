﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnJudging_Click(object sender, EventArgs e)
        {
            int year = Convert.ToInt32(txtYear .Text);
            if (year % 4 == 0 && year / 100 != 0 || year % 400 == 0)
            {
                lblShow.Text = string.Format("{0}年是闰年！", year);
            }
            else
            {
                lblShow.Text = string.Format("{0}年是非闰年！", year);
            }
        }
    }
}
