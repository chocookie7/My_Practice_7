﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(txtNumber .Text);
            int sum = 0;
            lblShow.Text = "输入的整数是：" + num;
            do
            {
                sum = sum + num % 10;
                num = num / 10;
            } while (num != 0);
            lblShow.Text +=" ；"+ string.Format("各位数字之和是：{0}",sum);
        }
    }
}
