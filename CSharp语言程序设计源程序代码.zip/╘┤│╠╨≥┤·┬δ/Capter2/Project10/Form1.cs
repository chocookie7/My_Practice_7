﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnJudging_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(txtNumber.Text); //将文本框输入的字符串转换成整数
            int n = (int)Math.Sqrt(num);             //调用Math.Sqrt()方法求num整数的平方根
            int i;
            //判断素数方法：将整数num一个个去除以这个数的平方根之间的所有数，若能整除，则不是素数，否则是素数
            for ( i = 2; i <= n; i++)
            {
                if (num % i == 0)
                {
                    break;   //不是素数，中止循环
                }
            }
            if (i <= n) 
            {
                lblShow.Text = string.Format("输入的正整数：{0},不是素数！", num);
            }
            else
            {
                lblShow.Text = string.Format("输入的正整数：{0},是素数！", num);
            }
        }   
    }
}
