﻿namespace Project1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtOldString = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInsertString = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtInsertIndex = new System.Windows.Forms.TextBox();
            this.txtSelect = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bntInsert = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.lblShow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "原字符串";
            // 
            // txtOldString
            // 
            this.txtOldString.Location = new System.Drawing.Point(76, 13);
            this.txtOldString.Name = "txtOldString";
            this.txtOldString.Size = new System.Drawing.Size(227, 21);
            this.txtOldString.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = " 插入字符串";
            // 
            // txtInsertString
            // 
            this.txtInsertString.Location = new System.Drawing.Point(76, 38);
            this.txtInsertString.Name = "txtInsertString";
            this.txtInsertString.Size = new System.Drawing.Size(227, 21);
            this.txtInsertString.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "插入位置";
            // 
            // txtInsertIndex
            // 
            this.txtInsertIndex.Location = new System.Drawing.Point(77, 63);
            this.txtInsertIndex.Name = "txtInsertIndex";
            this.txtInsertIndex.Size = new System.Drawing.Size(124, 21);
            this.txtInsertIndex.TabIndex = 5;
            // 
            // txtSelect
            // 
            this.txtSelect.Location = new System.Drawing.Point(76, 88);
            this.txtSelect.Name = "txtSelect";
            this.txtSelect.Size = new System.Drawing.Size(125, 21);
            this.txtSelect.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "查找子串";
            // 
            // bntInsert
            // 
            this.bntInsert.Location = new System.Drawing.Point(209, 63);
            this.bntInsert.Name = "bntInsert";
            this.bntInsert.Size = new System.Drawing.Size(95, 24);
            this.bntInsert.TabIndex = 8;
            this.bntInsert.Text = " 插入";
            this.bntInsert.UseVisualStyleBackColor = true;
            this.bntInsert.Click += new System.EventHandler(this.bntInsert_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(209, 88);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(95, 24);
            this.btnSelect.TabIndex = 9;
            this.btnSelect.Text = "查找";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // lblShow
            // 
            this.lblShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShow.Location = new System.Drawing.Point(12, 114);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(291, 71);
            this.lblShow.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 193);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.bntInsert);
            this.Controls.Add(this.txtSelect);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtInsertIndex);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtInsertString);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtOldString);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "字符串插入查找";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOldString;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInsertString;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtInsertIndex;
        private System.Windows.Forms.TextBox txtSelect;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bntInsert;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Label lblShow;
    }
}

