﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //实例化一个可变字符串对象，保存用户输入的字符串
        StringBuilder stringSave = new StringBuilder();
        private void bntInsert_Click(object sender, EventArgs e)
        {
            //将窗体文本框中输入的字符串追加到可变字符串对象stringSave的末尾
            stringSave.Append(txtOldString.Text);
            //获取插入字符串的索引
            int index = Convert.ToInt32(txtInsertIndex.Text);
            //调用可变字符串对象的插入方法，该方法有3个参数：插入位置、插入子字符串、插入次数
            stringSave.Insert(index, txtInsertString.Text, 1);
            lblShow.Text = stringSave.ToString();
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            stringSave.Append(txtOldString.Text);
            string oldstring = stringSave.ToString();
            //从左向右查找子串在原串的起始索引值
            int index = oldstring.IndexOf(txtSelect.Text);
            //判断索引index值，若为-1，则查找的子串不存原串中
            if (index == -1)
            {
                lblShow.Text += "\n查找的子字符串:"+txtSelect .Text +",不在原串中！";
            }
            else
            {
                lblShow.Text += "\n查找的子串:"+txtSelect .Text +",在原串中的索引值：" + index;
            }        
        }
    }
}
