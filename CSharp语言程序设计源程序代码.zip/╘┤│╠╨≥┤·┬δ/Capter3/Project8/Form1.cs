﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }  
           public  struct student
            { 
                private string stuNo;  //在结构型中声明5个私有成员
                private string stuName;
                private string stuSex;
                private int stuAge;
                private string stuSpec;
                public string StuNo    //采用属性来封装私有成员
                {
                    get { return stuNo; }
                    set { stuNo = value; }
                }        
                public string StuName
                {
                    get { return stuName; }
                    set { stuName = value; }
                }
                public string StuSex
                {
                    get { return stuSex; }
                    set { stuSex = value; }
                }
                public int StuAge   //对年龄字段封装，并判断若输入的是负整数，则返回0
                {
                    get { return stuAge; }
                    set
                    {
                        if (value < 0) { value  = 0; }
                        else { stuAge = value; }
                    }
                }
                public string StuSpec
                {
                    get { return stuSpec; }
                    set { stuSpec = value; }
                }              
            }      
        private void btnDisplay_Click(object sender, EventArgs e)
        {  
            student stu = new student();
            stu.StuNo = txtStuNo.Text;
            stu.StuName = txtStuName.Text;
            stu.StuSex = txtStuSex.Text;
            stu.StuAge = Convert.ToInt32(txtStuAge.Text);
            stu.StuSpec = txtStuSpecialty.Text;
            lblShow.Text = string.Format("学生基本信息：\n学号：{0}\n姓名：{1}\n性别：{2}\n年龄：{3}\n专业：{4}", stu.StuNo, stu.StuName,stu.StuSex ,stu.StuAge  ,stu.StuSpec );
            
        }
    }
}
