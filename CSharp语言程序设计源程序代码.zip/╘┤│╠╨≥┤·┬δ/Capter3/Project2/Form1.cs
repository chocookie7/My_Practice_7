﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnMaxvalue_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNumber1.Text);
            int num2 = Convert.ToInt32(txtNumber2.Text);
            int num3 = Convert.ToInt32(txtNumber3.Text);
            int maxnum = num1;
            if (num2 > maxnum) { maxnum = num2; }
            if (num3 > maxnum) { maxnum = num3; }       
            lblShow.Text = string.Format("输入的三个数是：{0} {1} {2}", num1, num2, num3);
            lblShow.Text += string.Format("\n三个数最大数是：{0}", maxnum);
        }
    }
}
