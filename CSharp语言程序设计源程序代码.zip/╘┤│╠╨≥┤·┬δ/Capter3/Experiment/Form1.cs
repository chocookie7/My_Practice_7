﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;//用户导入Regex类的命名空间

namespace Experiment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btbSubmit_Click(object sender, EventArgs e)
        {
            string userName = txtName.Text;
            string userPwd = txtPwd.Text;
            string userRsetPwd = txtResetPwd.Text;
            string email = txtEmail.Text;
            Regex regex = new Regex(@"^[A-Za-z]{6,}$");
            if (regex.IsMatch(userName))
            {
                MessageBox.Show("用户名格式正确！");
            }
            else
            {
                MessageBox.Show("用户名格式不正确!");
                return;
            }
            if (userPwd.Length >= 6 && userPwd.Length <= 14)
            {
                MessageBox.Show("密码长度符合要求！");
            }
            else
            {
                MessageBox.Show("密码长度不符合要求！");
                return;
            }
            //判断前后两次输入的密码是否一致
            if (txtPwd.Text == txtResetPwd.Text)
            {
                MessageBox.Show("两次输入的密码一致！");
            }
            else
            {
                MessageBox.Show("两次输入的密码不一致！");
                return;
            }

            regex = new Regex(@"^(\w)+(\.\w)*@(\w)+((\.\w+)+)+$");
            if (regex.IsMatch(email))
            {
                MessageBox.Show("邮箱格式正确！");
            }
            else
            {
                MessageBox.Show("邮箱格式不正确！");
                return;
            }
            string message = string.Format("用户注册的信息是:\n用户名：{0}\n密码：{1}\n邮箱：{2}\n", userName, userPwd, email);
            MessageBox.Show("用户信息注册成功！\n" +message );
        }
    }
}
