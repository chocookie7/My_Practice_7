﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;//使用Regex类需要用户导入的命名空间 

namespace Project3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            Regex rgx = new Regex(@"^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$");
            if (rgx.IsMatch(email))
            {
                lblShow.Text = "输入：" + txtEmail.Text + "邮箱格式正确！";
            }
            else
            {
                lblShow.Text = "输入：" + txtEmail.Text + "邮箱格式不正确！";
            }
        }
    }
}
