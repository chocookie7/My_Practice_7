﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        struct student
        {
            public string stuNo;
            public string stuName;
            public string stuSex;
            public int stuAge;
            public string stuSpec;
        }
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            student stu;
            stu.stuNo = txtStuNo.Text;
            stu.stuName = txtStuName.Text;
            stu.stuSex = txtStuSex.Text;
            stu.stuAge = Convert.ToInt32(txtStuAge.Text);
            stu.stuSpec = txtStuSpecialty.Text;
            lblShow.Text = string.Format("学生基本信息如下：\n学号：{0}\n姓名：{1}\n性别：{2}\n年龄：{3}\n专业：{4}\n", stu.stuNo, stu.stuName, stu.stuSex, stu.stuAge, stu.stuSpec);
        }
    }
}