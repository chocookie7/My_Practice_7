﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int[,] score = new int[3, 4] { { 85, 84, 86, 72 }, { 79, 89, 91, 83 }, { 83, 89, 96, 85 } };
            for (int i = 0; i < score.GetLength(0); i++)
            {
                lblShow.Text += string.Format("第{0}个学生成绩：", i + 1);
                for (int j = 0; j < score.GetLength(1); j++)
                {
                    lblShow.Text += string.Format("{0}   ", score[i, j]);    
                } 
                lblShow.Text += "\n";
                }
            }
        }
}
