﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const int Max = 5; //定义符号常量，表示数组的长度
        static int num = 0;//定义静态变量，表示数组索引值
        int[] array1 = new int[Max];
        int[] array2 = new int[Max];
        private void btnAdd_Click(object sender, EventArgs e)
        {
            array1[num] = Convert.ToInt32(txtElement.Text);
            lblShow.Text += string.Format("\n添加第{0}个数组元素成功，元素值是：{1}", num, txtElement.Text);
            num++;
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Array.Copy(array1, array2, num );//将数组array1的所有元素复制到数组array2中
            lblShow.Text = "数组array2的原始元素分别是：";
            for (int i = 0; i < array2.Length; i++)
            {
                lblShow.Text += " " + array2[i];
            }
            lblShow.Text += "\n数组array2排序后元素分别是：";
            Array.Sort(array2);
            for (int i = 0; i < array2.Length; i++)
            {
                lblShow.Text += " " + array2[i];
            }
            lblShow.Text += "\n数据array2元素反转：   ";
            Array.Reverse(array2);
            for (int i = 0; i < array2.Length; i++)
            {
                lblShow.Text += " " + array2[i];
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            //在数组array2中查找是否有txtElement.Text中输入的元素
            int index = Array.IndexOf(array2, Convert.ToInt32(txtElement.Text));
            if (index == -1)
            {
                lblShow.Text += "\n数组array2中不存在要查找的元素：" + txtElement.Text;
            }
            else
            {
                lblShow.Text += string.Format("\n{0}是数组array2反转后的第{1}元素", txtElement.Text, index);
            }
        }
    }
}
