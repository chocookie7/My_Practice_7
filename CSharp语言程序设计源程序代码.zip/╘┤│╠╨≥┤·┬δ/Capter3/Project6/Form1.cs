﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public enum Title : int
        {
            助教,讲师,副教授,教授,特级教授
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            #region //1.常规方法输出枚举值
            //lblShow.Text = Title.助教 + ": " + (int)Title.助教;
            //lblShow.Text += "\n" + Title.讲师 + ": " + (int)Title.讲师;
            //lblShow.Text += "\n" + Title.副教授 + ": " + (int)Title.副教授;
            //lblShow.Text += "\n" + Title.教授 + ": " + (int)Title.教授;
            //lblShow.Text += "\n" + Title.特级教授 + ": " + (int)Title.特级教授;
            #endregion
            #region 2.采用Type类型输出枚举值
            Type title = typeof(Title);
            Array ay = Enum.GetValues(title);
            for (int i = 0; i < ay.Length; i++)
            {
                lblShow.Text += "\n" + ay.GetValue(i)+"  "+i;
            }
            #endregion
        }
    }
}
