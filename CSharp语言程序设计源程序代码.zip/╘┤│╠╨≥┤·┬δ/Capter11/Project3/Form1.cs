﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading; //线程类Thread所在的命名空间

namespace Project3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //在From1窗体的加载事件中不检查跨线程的调用是否合法；如果检查调用合法则会抛出异常
            Control.CheckForIllegalCrossThreadCalls = false;
            Thread thread = new Thread(PrintOdd);
            thread.IsBackground = true;
        }
        //输出1-10的奇数按钮单击事件
        private void btnPrint_Click(object sender, EventArgs e)
        {
            ThreadStart ts = new ThreadStart(PrintOdd);
            Thread td = new Thread(ts);
            td.Start();
        }
        //定义打印1-10中奇数的方法
        private void PrintOdd()
        {
            for (int i = 1; i < 10; i = i + 2)
            {
                rtbShow.Text = rtbShow.Text + i+"\n";
            }
        }

       
    }
}
