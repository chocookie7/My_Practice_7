﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Project6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //在From1窗体的加载事件中不检查跨线程的调用是否合法；如果检查调用合法则会抛出异常
            Control.CheckForIllegalCrossThreadCalls = false;
            Thread tsodd = new Thread(PrintOdd);
            tsodd.IsBackground = true;
            Thread tdeven = new Thread(PrintEven);
            tdeven.IsBackground = true;

        }
        //定义打印0-10中偶数线程的方法
        private void PrintEven()
        {
            lock (this)
            {
                for (int i = 0; i <= 10; i = i + 2)
                {
                    rtbShow.Text = rtbShow.Text + i + "\n";
                }
            }
        }
        //定义打印1-10中奇数线程的方法
        private void PrintOdd()
        {
            lock (this)
            {
                for (int i = 1; i <= 10; i = i + 2)
                {
                    rtbShow.Text = rtbShow.Text + i + "\n";
                }
            }
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            ThreadStart tsOdd = new ThreadStart(PrintOdd);
            Thread tdOdd = new Thread(tsOdd );
            tdOdd.Start();
            ThreadStart tsEven = new ThreadStart(PrintEven);
            Thread tdEven = new Thread(tsEven);        
            tdEven.Start();
        }

       
    }
}
