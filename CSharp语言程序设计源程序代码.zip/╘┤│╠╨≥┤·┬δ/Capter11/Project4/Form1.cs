﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Project4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //在From1窗体的加载事件中不检查跨线程的调用是否合法；如果检查调用合法则会抛出异常
            Control.CheckForIllegalCrossThreadCalls = false;
            Thread thread = new Thread(PrintOdd);
            thread.IsBackground = true;
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            ParameterizedThreadStart pts = new ParameterizedThreadStart(PrintOdd);
            Thread td = new Thread(pts);
            td.Start(10);
        }
        private void PrintOdd( object  n)
        {
            for (int i = 1; i <= (int)n; i = i + 2)
            {
                rtbShow.Text = rtbShow.Text + i + "\n";
            }
        }

       
    }
}
