﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //在From1窗体的加载事件中不检查跨线程的调用是否合法；如果检查调用合法则会抛出异常
            Control.CheckForIllegalCrossThreadCalls = false;
            Thread tsodd = new Thread(PrintOdd);
            tsodd.IsBackground = true;
            Thread tdeven = new Thread(PrintEven);
            tdeven.IsBackground = true;
            
        }
        //定义打印1-10中的奇数的方法
        private  void PrintOdd()
        {
            for (int i = 1; i <= 10; i = i + 2)
            {
                Thread.Sleep(1000);
                rtbShow.Text = rtbShow.Text + i + "\n";
            }
            
        }
        //定义打印0-10中偶数的方法
        private void PrintEven()
        {
            for (int i = 0; i <= 10; i = i + 2)
            {
                Thread.Sleep(1000);
                rtbShow.Text = rtbShow.Text + i + "\n";
            }
            
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            ThreadStart tsodd = new ThreadStart(PrintOdd);
            Thread tdodd = new Thread(tsodd);
            //设置奇数线程为低优先级
            tdodd.Priority = ThreadPriority.Lowest;
            ThreadStart tseven = new ThreadStart(PrintEven);
            Thread tdeven = new Thread(tseven);
            //设置偶数线程为高优先级
            tdeven.Priority = ThreadPriority.Highest;
            tdodd.Start();
            tdeven.Start();
            

        }
    }
}
