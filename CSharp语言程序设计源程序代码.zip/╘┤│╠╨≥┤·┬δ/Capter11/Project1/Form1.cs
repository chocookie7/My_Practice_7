﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;//使用Process类所需的命名空间

namespace Project1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            //定义一个进程类数组processes，同时将本地计算机的每个进程资源创建一个新的进程类对象组件保存到该数组中
            Process[] processes = Process.GetProcesses();
            //遍历进程数组中存放的每个进程
            foreach (Process ps in processes)
            {
                rtbProcesses.Text = rtbProcesses.Text + ps.ProcessName + "\r\n";
            }
        }
    }
}
