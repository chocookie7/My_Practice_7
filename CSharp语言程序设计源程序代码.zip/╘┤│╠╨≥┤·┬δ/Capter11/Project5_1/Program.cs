﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Project5_1
{
    class Program
    {
        //定义打印1-100中的奇数的方法
        private static void PrintOdd()
        {
            for (int i = 1; i <= 100; i = i + 2)
            {
               // Console.Write("{0} ",i);
                Thread.Sleep(10000);
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.ReadKey();
        }
        //定义打印0-100中偶数的方法
        private static void PrintEven()
        {
            for (int i = 0; i <= 100; i = i + 2)
            {
                //Console.Write("{0} ", i);
                Thread.Sleep(10000); //让线程休眠10秒
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.ReadKey();
        }
        static void Main(string[] args)
        {
            ThreadStart tsodd = new ThreadStart(PrintOdd);
            Thread tdodd = new Thread(tsodd);
            tdodd.Priority = ThreadPriority.Highest;
            ThreadStart tseven = new ThreadStart(PrintEven);
            Thread tdeven = new Thread(tseven);
            tdeven.Priority = ThreadPriority.Lowest;
            tdodd.Start();
            tdeven.Start();
        }
    }
}
