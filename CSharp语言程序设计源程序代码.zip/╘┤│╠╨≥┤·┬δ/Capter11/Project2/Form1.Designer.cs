﻿namespace Project2
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateandStart = new System.Windows.Forms.Button();
            this.rtbShowThread = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnCreateandStart
            // 
            this.btnCreateandStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateandStart.Location = new System.Drawing.Point(8, 14);
            this.btnCreateandStart.Name = "btnCreateandStart";
            this.btnCreateandStart.Size = new System.Drawing.Size(359, 32);
            this.btnCreateandStart.TabIndex = 0;
            this.btnCreateandStart.Text = "创建线程并启动";
            this.btnCreateandStart.UseVisualStyleBackColor = true;
            this.btnCreateandStart.Click += new System.EventHandler(this.btnCreateandStart_Click);
            // 
            // rtbShowThread
            // 
            this.rtbShowThread.Location = new System.Drawing.Point(1, 57);
            this.rtbShowThread.Name = "rtbShowThread";
            this.rtbShowThread.Size = new System.Drawing.Size(369, 241);
            this.rtbShowThread.TabIndex = 2;
            this.rtbShowThread.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 308);
            this.Controls.Add(this.rtbShowThread);
            this.Controls.Add(this.btnCreateandStart);
            this.Name = "Form1";
            this.Text = "创建和启动线程";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCreateandStart;
        private System.Windows.Forms.RichTextBox rtbShowThread;
    }
}

