﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading; //创建并控制线程类Thread所需要的命名空间

namespace Project2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreateandStart_Click(object sender, EventArgs e)
        {
            Thread.CurrentThread.Name = "主线程";  //修改当前线程的线程名
            Thread objThread = new Thread(new ThreadStart(ActionMethod));//创建线程
            objThread.Name = "子线程";
            objThread.Start();
            ActionMethod();
        }
        private void  ActionMethod() //线程调用的方法
        {
           
            for (int count = 1; count <= 5; count++)
            {
                rtbShowThread.Text = rtbShowThread.Text + Thread.CurrentThread.Name + "第" + count + "次\n";
                    
            }
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //在From1窗体的加载事件中不检查跨线程的调用是否合法；如果检查调用合法则会抛出异常
            Control.CheckForIllegalCrossThreadCalls = false;
            Thread thread = new Thread(ActionMethod);
            thread.IsBackground = true;
        }      
    }
}
